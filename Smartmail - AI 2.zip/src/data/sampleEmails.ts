import { Email, Task } from '../types';

export const INITIAL_SAMPLE_EMAILS: Email[] = [
  {
    id: 'em-1',
    sender: 'Prof. David Martinez',
    senderEmail: 'dmartinez@university.edu',
    recipient: 'student@university.edu',
    subject: 'CS304 Final Project Milestone 2: Submission Details & Presentation Slots',
    date: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 mins ago
    read: false,
    starred: true,
    category: 'Academic',
    priority: 'Urgent',
    body: `Dear CS304 Students,

This is a reminder that Milestone 2 of your Distributed Systems final project is due this Friday, November 2nd at 11:59 PM.

Please ensure the following deliverables are satisfied:
1. Complete code committed to your team GitHub repository with a verified README containing build instructions.
2. Unit tests achieving at least 80% coverage on your replication manager module.
3. Book a mandatory 15-minute live demo slot with the TAs using the portal by Thursday 5:00 PM.

Failure to schedule your demo slot before Thursday will result in a 10% penalty on the presentation grade. Office hours are available on Wednesday afternoon if your team is experiencing deployment issues on the campus cluster.

Best regards,
Prof. David Martinez
Department of Computer Science`,
    aiSummary: {
      summary: 'Prof. Martinez reminds students that CS304 Milestone 2 is due Friday Nov 2 at 11:59 PM. Teams must push code with >=80% test coverage and book a mandatory demo slot by Thursday 5:00 PM.',
      keyPoints: [
        'Milestone 2 due Friday at 11:59 PM with >=80% test coverage.',
        'Mandatory 15-minute TA demo must be booked by Thursday 5:00 PM.',
        'Cluster deployment office hours available Wednesday afternoon.'
      ],
      sentiment: 'Action-Required',
      confidence: 0.98,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    },
    tasksExtracted: true,
  },
  {
    id: 'em-2',
    sender: 'Sarah Jenkins',
    senderEmail: 's.jenkins@innovatetech.io',
    recipient: 'student@university.edu',
    subject: 'InnovateTech: Invitation for Summer 2027 Software Engineering Internship Interview',
    date: new Date(Date.now() - 1000 * 60 * 180).toISOString(), // 3 hours ago
    read: false,
    starred: true,
    category: 'Work',
    priority: 'High',
    body: `Hi there,

Thank you for your application to the Summer 2027 Software Engineering Internship position at InnovateTech!

Our engineering review committee was thoroughly impressed by your distributed systems coursework and full-stack projects on GitHub. We would love to move you forward to the Technical Screening round (45 minutes via Google Meet).

Please confirm your availability for one of the following interview slots:
- Option A: Tuesday, Nov 4th at 2:00 PM EST
- Option B: Wednesday, Nov 5th at 11:00 AM EST
- Option C: Thursday, Nov 6th at 3:30 PM EST

Please reply with your preferred time slot and an updated copy of your resume by tomorrow at 4:00 PM EST so we can lock in the calendar invite.

We look forward to speaking with you!

Warm regards,
Sarah Jenkins
Technical Talent Acquisition | InnovateTech`,
    aiSummary: {
      summary: 'InnovateTech invited you to a 45-minute technical screening for the Summer 2027 SWE internship. You must reply with your preferred time slot and updated resume by tomorrow at 4:00 PM EST.',
      keyPoints: [
        'Advancing to 45-min Google Meet technical interview.',
        'Three time slot choices offered between Nov 4th and Nov 6th.',
        'Action required: Reply with preferred slot and resume before tomorrow 4:00 PM EST.'
      ],
      sentiment: 'Action-Required',
      confidence: 0.97,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 170).toISOString(),
    },
    tasksExtracted: true,
  },
  {
    id: 'em-3',
    sender: 'CloudOps Security Alert',
    senderEmail: 'security-bot@cloudops-monitor.net',
    recipient: 'student@university.edu',
    subject: 'URGENT: Exposed Secret Detected in Public GitHub Repository',
    date: new Date(Date.now() - 1000 * 60 * 300).toISOString(), // 5 hours ago
    read: true,
    starred: true,
    category: 'Urgent',
    priority: 'Urgent',
    body: `CRITICAL SECURITY NOTIFICATION:

Our automated Git scanning tool detected a potential API secret key pushed to your public repository 'student/portfolio-agent' in commit 8f9b21a.

Token Type: PostgreSQL / Service Connection String
Detected at: config/database.ts:14

Required Immediate Mitigation:
1. Immediately revoke the exposed token or rotate credentials in your provider dashboard.
2. Remove the sensitive string from Git commit history using git-filter-repo or BFG Repo-Cleaner.
3. Verify that environment variables (.env) are included in .gitignore before making further commits.

Please acknowledge this alert once credentials have been safely invalidated.`,
    aiSummary: {
      summary: 'Automated security alert: A database connection string was committed to public repo "student/portfolio-agent". Immediate key revocation and Git history sanitization required.',
      keyPoints: [
        'High severity exposed credential detected in public commit 8f9b21a.',
        'Requires immediate secret revocation in provider dashboard.',
        'Sanitize commit history and ensure .env is gitignored.'
      ],
      sentiment: 'Action-Required',
      confidence: 0.99,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 290).toISOString(),
    },
    tasksExtracted: true,
  },
  {
    id: 'em-4',
    sender: 'Alex Rivera',
    senderEmail: 'arivera.roommate@gmail.com',
    recipient: 'student@university.edu',
    subject: 'Apartment Utility Bill & Groceries Split (October)',
    date: new Date(Date.now() - 1000 * 60 * 60 * 14).toISOString(), // 14 hours ago
    read: true,
    starred: false,
    category: 'Personal',
    priority: 'Medium',
    body: `Hey!

Hope your midterms went well! Here is the breakdown for our apartment expenses for this past month:

- High-speed Fiber Internet: $70.00 ($35.00 each)
- Electric & Gas (ConEd): $94.60 ($47.30 each)
- Shared household supplies (Costco run): $28.40 ($14.20 each)

Your total share comes to $96.50. Could you Venmo or Zelle me before this Sunday so I can pay the utility autopay on time?

Also let me know if we're still hosting the movie night this Friday!

Cheers,
Alex`,
    aiSummary: {
      summary: 'Roommate Alex sent the monthly apartment expense breakdown totaling $96.50 for internet, electric, and Costco supplies. Payment requested via Venmo/Zelle before Sunday.',
      keyPoints: [
        'Total amount due: $96.50 for October utilities and household supplies.',
        'Send payment via Venmo or Zelle before Sunday.',
        'Follow up on Friday movie night plans.'
      ],
      sentiment: 'Informational',
      confidence: 0.96,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 60 * 13).toISOString(),
    },
    tasksExtracted: true,
  },
  {
    id: 'em-5',
    sender: 'GitHub Education',
    senderEmail: 'student-pack@github.com',
    recipient: 'student@university.edu',
    subject: 'Your GitHub Student Developer Pack Benefits Have Been Renewed',
    date: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), // 1 day ago
    read: true,
    starred: false,
    category: 'Promotional',
    priority: 'Low',
    body: `Welcome back to the GitHub Student Developer Pack!

Your academic verification for the 2026-2027 school year was approved. You now have continued access to over $200k in free developer tools, including:

- GitHub Copilot free access while enrolled
- 1 Free year domain registration with Namecheap
- $100 in DigitalOcean cloud credits
- Free JetBrains IDE Ultimate subscriptions

Explore the updated offers in your student dashboard and start shipping today!`,
    aiSummary: {
      summary: 'GitHub has approved your academic verification for 2026-2027, renewing free access to GitHub Copilot, JetBrains IDEs, and developer cloud credits.',
      keyPoints: [
        'Academic verification renewed for 2026-2027.',
        'Free GitHub Copilot and JetBrains IDE licenses active.',
        'Claim domain and cloud credits through student dashboard.'
      ],
      sentiment: 'Appreciative',
      confidence: 0.94,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 60 * 25).toISOString(),
    },
    tasksExtracted: false,
  },
  {
    id: 'em-6',
    sender: 'Dr. Elena Rostova',
    senderEmail: 'erostova@university.edu',
    recipient: 'student@university.edu',
    subject: 'NLP Lab Research Assistant Position - Discussion & Paper Draft',
    date: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(), // 1.5 days ago
    read: false,
    starred: true,
    category: 'Academic',
    priority: 'High',
    body: `Hello,

I reviewed your code submission for the benchmark evaluation script on transformer attention pruning. The performance metrics look very solid and match our initial hypothesis.

I have attached our working preprint draft. Please review Section 3 (Methodology) and Section 4.2 (Empirical Results). Could you write a brief 2-paragraph analysis of the latency vs. perplexity trade-offs before our lab meeting on Thursday at 10:00 AM?

Also let me know if you would like to be listed as co-author on the workshop submission.

Best regards,
Dr. Elena Rostova
Associate Professor | Natural Language Processing Lab`,
    aiSummary: {
      summary: 'Dr. Rostova praised your benchmark evaluation script and requested a 2-paragraph analysis of Section 3 & 4.2 trade-offs before the Thursday 10:00 AM lab meeting.',
      keyPoints: [
        'Transformer benchmark results confirmed solid.',
        'Write 2-paragraph analysis on latency vs. perplexity trade-offs.',
        'Deadline: Before Thursday 10:00 AM lab meeting.'
      ],
      sentiment: 'Action-Required',
      confidence: 0.98,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 60 * 35).toISOString(),
    },
    tasksExtracted: true,
  },
  {
    id: 'em-7',
    sender: 'HackNation 2026 Organizing Team',
    senderEmail: 'registration@hacknation2026.org',
    recipient: 'student@university.edu',
    subject: 'You are Confirmed for HackNation 2026! Complete Team RSVP',
    date: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    read: true,
    starred: false,
    category: 'Personal',
    priority: 'Medium',
    body: `Congratulations hacker!

Your application for HackNation 2026 has been accepted! Over 3,500 students applied, and you are one of 500 hackers selected to build in-person at the Metro Convention Center on November 15-16.

To secure your spot and receive your hacker swag kit, please complete the final RSVP form and dietary preferences link before this Friday at 11:59 PM.

Hardware lab requests for Raspberry Pi 5 kits and Coral TPUs are also open on a first-come, first-served basis.

Happy hacking!
The HackNation Team`,
    aiSummary: {
      summary: 'Accepted to HackNation 2026 in-person hackathon on Nov 15-16. Must complete the final RSVP form and dietary survey before Friday 11:59 PM to secure spot.',
      keyPoints: [
        'Accepted into HackNation 2026 (Nov 15-16).',
        'Complete RSVP and dietary preferences form before Friday 11:59 PM.',
        'Hardware lab reservation open for Raspberry Pi 5 & TPU kits.'
      ],
      sentiment: 'Appreciative',
      confidence: 0.95,
      modelUsed: 'gemini-3.8-flash',
      analyzedAt: new Date(Date.now() - 1000 * 60 * 60 * 47).toISOString(),
    },
    tasksExtracted: true,
  }
];

export const INITIAL_SAMPLE_TASKS: Task[] = [
  {
    id: 'task-1',
    title: 'Revoke and rotate exposed database connection secret',
    description: 'CloudOps detected exposed secret in repository student/portfolio-agent commit 8f9b21a',
    deadline: 'Within 2 hours',
    priority: 'Urgent',
    category: 'Urgent',
    completed: false,
    sourceEmailId: 'em-3',
    sourceEmailSubject: 'URGENT: Exposed Secret Detected in Public GitHub Repository',
    createdAt: new Date(Date.now() - 1000 * 60 * 290).toISOString(),
  },
  {
    id: 'task-2',
    title: 'Book 15-minute CS304 TA demo slot',
    description: 'Mandatory demo slot for Milestone 2 with TA before 5:00 PM deadline',
    deadline: 'Thursday by 5:00 PM',
    priority: 'Urgent',
    category: 'Academic',
    completed: false,
    sourceEmailId: 'em-1',
    sourceEmailSubject: 'CS304 Final Project Milestone 2: Submission Details & Presentation Slots',
    createdAt: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
  },
  {
    id: 'task-3',
    title: 'Reply to Sarah (InnovateTech) with interview time slot and resume',
    description: 'Choose between Tuesday 2pm, Wednesday 11am, or Thursday 3:30pm EST',
    deadline: 'Tomorrow by 4:00 PM EST',
    priority: 'High',
    category: 'Work',
    completed: false,
    sourceEmailId: 'em-2',
    sourceEmailSubject: 'InnovateTech: Invitation for Summer 2027 SWE Internship Interview',
    createdAt: new Date(Date.now() - 1000 * 60 * 170).toISOString(),
  },
  {
    id: 'task-4',
    title: 'Submit CS304 Milestone 2 GitHub repository & test coverage report',
    description: 'Replication manager module unit tests with >=80% coverage and README build docs',
    deadline: 'Friday by 11:59 PM',
    priority: 'High',
    category: 'Academic',
    completed: false,
    sourceEmailId: 'em-1',
    sourceEmailSubject: 'CS304 Final Project Milestone 2: Submission Details & Presentation Slots',
    createdAt: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
  },
  {
    id: 'task-5',
    title: 'Write 2-paragraph latency vs perplexity analysis for Dr. Rostova',
    description: 'Review Section 3 and 4.2 of transformer attention pruning draft before lab meeting',
    deadline: 'Thursday by 10:00 AM',
    priority: 'High',
    category: 'Academic',
    completed: false,
    sourceEmailId: 'em-6',
    sourceEmailSubject: 'NLP Lab Research Assistant Position - Discussion & Paper Draft',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 35).toISOString(),
  },
  {
    id: 'task-6',
    title: 'Complete HackNation 2026 RSVP and dietary form',
    description: 'Confirm attendance for in-person hackathon Swag and hardware lab kit',
    deadline: 'Friday by 11:59 PM',
    priority: 'Medium',
    category: 'Personal',
    completed: true,
    completedAt: new Date(Date.now() - 1000 * 60 * 60 * 10).toISOString(),
    sourceEmailId: 'em-7',
    sourceEmailSubject: 'You are Confirmed for HackNation 2026! Complete Team RSVP',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 47).toISOString(),
  },
  {
    id: 'task-7',
    title: 'Venmo $96.50 to Alex for October utilities & internet',
    description: 'Internet ($35.00) + Electric ($47.30) + Costco supplies ($14.20)',
    deadline: 'Sunday before 11:59 PM',
    priority: 'Medium',
    category: 'Personal',
    completed: false,
    sourceEmailId: 'em-4',
    sourceEmailSubject: 'Apartment Utility Bill & Groceries Split (October)',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 13).toISOString(),
  }
];
