import React from 'react';
import {
  LayoutDashboard,
  Inbox,
  GraduationCap,
  Briefcase,
  AlertOctagon,
  User,
  Tag,
  CheckSquare,
  Sparkles,
  Database,
  HelpCircle,
  Mail,
  ShieldCheck,
} from 'lucide-react';
import { Category } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedCategory: Category | 'All';
  setSelectedCategory: (cat: Category | 'All') => void;
  unreadCount: number;
  urgentCount: number;
  pendingTasksCount: number;
  categoryCounts: Record<Category, number>;
  onOpenGuideModal: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  selectedCategory,
  setSelectedCategory,
  unreadCount,
  urgentCount,
  pendingTasksCount,
  categoryCounts,
  onOpenGuideModal,
  isOpenMobile,
  onCloseMobile,
}) => {
  const handleNavClick = (tab: string, category: Category | 'All' = 'All') => {
    setActiveTab(tab);
    setSelectedCategory(category);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs md:hidden"
        />
      )}

      <aside
        className={`fixed md:sticky top-0 left-0 z-40 h-screen w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-slate-900 tracking-tight text-base">SmartMail</span>
                <span className="px-1.5 py-0.5 text-[10px] font-extrabold uppercase bg-blue-100 text-blue-700 rounded-md">AI</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Task & Mail Automation</p>
            </div>
          </div>
        </div>

        {/* Navigation Section */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {/* Main Views */}
          <div className="space-y-1">
            <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">Main Navigation</p>
            
            <button
              onClick={() => handleNavClick('dashboard')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'dashboard'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <LayoutDashboard className="w-4 h-4 text-blue-600" />
                <span>Dashboard</span>
              </div>
            </button>

            <button
              onClick={() => handleNavClick('emails', 'All')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'All'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <Inbox className="w-4 h-4 text-slate-500" />
                <span>All Inbox</span>
              </div>
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 text-xs font-semibold bg-blue-600 text-white rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('tasks')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeTab === 'tasks'
                  ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <CheckSquare className="w-4 h-4 text-emerald-600" />
                <span>Action Items & Tasks</span>
              </div>
              {pendingTasksCount > 0 && (
                <span className="px-2 py-0.5 text-xs font-semibold bg-emerald-100 text-emerald-700 rounded-full">
                  {pendingTasksCount}
                </span>
              )}
            </button>
          </div>

          {/* AI Categories */}
          <div className="space-y-1">
            <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">AI Categories</p>

            {/* Academic */}
            <button
              onClick={() => handleNavClick('emails', 'Academic')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'Academic'
                  ? 'bg-indigo-50 text-indigo-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <GraduationCap className="w-4 h-4 text-indigo-500" />
                <span>Academic & Courses</span>
              </div>
              <span className="text-xs text-slate-400 font-medium">{categoryCounts.Academic || 0}</span>
            </button>

            {/* Work */}
            <button
              onClick={() => handleNavClick('emails', 'Work')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'Work'
                  ? 'bg-sky-50 text-sky-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Briefcase className="w-4 h-4 text-sky-500" />
                <span>Work & Internships</span>
              </div>
              <span className="text-xs text-slate-400 font-medium">{categoryCounts.Work || 0}</span>
            </button>

            {/* Urgent */}
            <button
              onClick={() => handleNavClick('emails', 'Urgent')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'Urgent'
                  ? 'bg-rose-50 text-rose-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <AlertOctagon className="w-4 h-4 text-rose-500" />
                <span>Urgent & Deadlines</span>
              </div>
              {urgentCount > 0 && (
                <span className="px-1.5 py-0.2 text-[11px] font-bold bg-rose-600 text-white rounded-full">
                  {urgentCount}
                </span>
              )}
            </button>

            {/* Personal */}
            <button
              onClick={() => handleNavClick('emails', 'Personal')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'Personal'
                  ? 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <User className="w-4 h-4 text-emerald-500" />
                <span>Personal</span>
              </div>
              <span className="text-xs text-slate-400 font-medium">{categoryCounts.Personal || 0}</span>
            </button>

            {/* Promotional */}
            <button
              onClick={() => handleNavClick('emails', 'Promotional')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeTab === 'emails' && selectedCategory === 'Promotional'
                  ? 'bg-purple-50 text-purple-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Tag className="w-4 h-4 text-purple-500" />
                <span>Promotional & Deals</span>
              </div>
              <span className="text-xs text-slate-400 font-medium">{categoryCounts.Promotional || 0}</span>
            </button>
          </div>

          {/* Quick Info Box for Student Developers */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <span>Zero-Cost Local DB</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Stored persistently in IndexedDB. No external paid database or credit card needed.
            </p>
            <button
              onClick={onOpenGuideModal}
              className="text-[11px] text-blue-600 font-semibold hover:underline flex items-center gap-1"
            >
              <HelpCircle className="w-3 h-3" />
              <span>How to run in VS Code</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 text-xs text-slate-400 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <Database className="w-3.5 h-3.5 text-slate-400" />
            <span>SmartMail Agent v1.0</span>
          </span>
          <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">CS-304</span>
        </div>
      </aside>
    </>
  );
};
