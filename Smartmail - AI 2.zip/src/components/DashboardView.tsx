import React from 'react';
import {
  Mail,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
  GraduationCap,
  Briefcase,
  AlertOctagon,
  User,
  Tag,
  CheckSquare,
  ExternalLink,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { Email, Task, Category } from '../types';

interface DashboardViewProps {
  emails: Email[];
  tasks: Task[];
  onSelectEmail: (email: Email) => void;
  onToggleTask: (taskId: string) => void;
  onNavigateToTab: (tab: string, category?: Category | 'All') => void;
  onOpenNewEmailModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  emails,
  tasks,
  onSelectEmail,
  onToggleTask,
  onNavigateToTab,
  onOpenNewEmailModal,
}) => {
  // Metrics calculation
  const totalEmails = emails.length;
  const urgentEmails = emails.filter((e) => e.priority === 'Urgent' || e.category === 'Urgent').length;
  const pendingTasks = tasks.filter((t) => !t.completed).length;
  const completedTasks = tasks.filter((t) => t.completed).length;

  // Upcoming deadlines (tasks pending with deadline specified)
  const upcomingDeadlineTasks = tasks
    .filter((t) => !t.completed)
    .sort((a, b) => {
      // Prioritize Urgent/High
      const priorityOrder: Record<string, number> = { Urgent: 0, High: 1, Medium: 2, Low: 3 };
      return (priorityOrder[a.priority] ?? 4) - (priorityOrder[b.priority] ?? 4);
    })
    .slice(0, 5);

  // Category counts
  const categoryCounts: Record<Category, number> = {
    Academic: emails.filter((e) => e.category === 'Academic').length,
    Work: emails.filter((e) => e.category === 'Work').length,
    Urgent: emails.filter((e) => e.category === 'Urgent').length,
    Personal: emails.filter((e) => e.category === 'Personal').length,
    Promotional: emails.filter((e) => e.category === 'Promotional').length,
  };

  const recentEmails = [...emails]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const taskCompletionRate = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-10">
          <Sparkles className="w-64 h-64 text-white" />
        </div>
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white/15 text-blue-100 backdrop-blur-xs border border-white/20">
            <Sparkles className="w-3.5 h-3.5 text-blue-200" />
            <span>AI Automated Email & Task Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Welcome back! Here's your executive digest.
          </h1>
          <p className="text-sm text-blue-100/90 leading-relaxed">
            SmartMail AI has analyzed <span className="font-semibold text-white">{totalEmails} emails</span> and identified{' '}
            <span className="font-semibold text-white">{pendingTasks} actionable tasks</span> with upcoming deadlines.
          </p>
          <div className="pt-2 flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigateToTab('tasks')}
              className="px-4 py-2 bg-white text-blue-700 font-semibold rounded-lg text-xs sm:text-sm hover:bg-blue-50 transition shadow-sm flex items-center gap-1.5"
            >
              <CheckSquare className="w-4 h-4 text-blue-600" />
              <span>Review Pending Tasks</span>
            </button>
            <button
              onClick={onOpenNewEmailModal}
              className="px-4 py-2 bg-blue-500/30 hover:bg-blue-500/50 text-white font-medium rounded-lg text-xs sm:text-sm transition border border-white/20 flex items-center gap-1.5"
            >
              <Mail className="w-4 h-4" />
              <span>Simulate Incoming Email</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5 Top KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Emails */}
        <div
          onClick={() => onNavigateToTab('emails', 'All')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Emails</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition">
              <Mail className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{totalEmails}</p>
          <div className="flex items-center gap-1 text-[11px] text-blue-600 mt-1 font-medium">
            <span>View all inbox</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* Urgent Emails */}
        <div
          onClick={() => onNavigateToTab('emails', 'Urgent')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-rose-400 hover:shadow-sm transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Urgent Emails</span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-lg group-hover:bg-rose-600 group-hover:text-white transition">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{urgentEmails}</p>
          <div className="flex items-center gap-1 text-[11px] text-rose-600 mt-1 font-medium">
            <span>Immediate attention</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* Pending Tasks */}
        <div
          onClick={() => onNavigateToTab('tasks')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-amber-400 hover:shadow-sm transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Pending Tasks</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg group-hover:bg-amber-600 group-hover:text-white transition">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{pendingTasks}</p>
          <div className="flex items-center gap-1 text-[11px] text-amber-600 mt-1 font-medium">
            <span>Action items to do</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* Completed Tasks */}
        <div
          onClick={() => onNavigateToTab('tasks')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-emerald-400 hover:shadow-sm transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Completed Tasks</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg group-hover:bg-emerald-600 group-hover:text-white transition">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{completedTasks}</p>
          <div className="flex items-center gap-1 text-[11px] text-emerald-600 mt-1 font-medium">
            <span>{taskCompletionRate}% completion rate</span>
          </div>
        </div>

        {/* Upcoming Deadlines */}
        <div
          onClick={() => onNavigateToTab('tasks')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:shadow-sm transition cursor-pointer group col-span-2 sm:col-span-1"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Upcoming Deadlines</span>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg group-hover:bg-indigo-600 group-hover:text-white transition">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{upcomingDeadlineTasks.length}</p>
          <div className="flex items-center gap-1 text-[11px] text-indigo-600 mt-1 font-medium">
            <span>Next due dates</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition" />
          </div>
        </div>
      </div>

      {/* Main Grid: Upcoming Deadlines & Category Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Urgent Deadlines & Action Items (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-rose-500" />
                <span>Priority Action Items & Deadlines</span>
              </h2>
              <p className="text-xs text-slate-500">Extracted automatically from incoming emails by SmartMail AI</p>
            </div>
            <button
              onClick={() => onNavigateToTab('tasks')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <span>View all</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {upcomingDeadlineTasks.length === 0 ? (
              <div className="py-8 text-center text-slate-400">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
                <p className="text-sm font-medium">All caught up! No urgent pending deadlines.</p>
              </div>
            ) : (
              upcomingDeadlineTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-start justify-between gap-3 p-3 rounded-lg border border-slate-200/80 bg-slate-50/60 hover:bg-slate-100/70 transition"
                >
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <button
                      onClick={() => onToggleTask(task.id)}
                      className="mt-0.5 text-slate-400 hover:text-emerald-600 transition"
                      title="Mark task completed"
                    >
                      <div className="w-5 h-5 rounded border border-slate-300 flex items-center justify-center hover:border-emerald-500 hover:bg-emerald-50">
                        {task.completed && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                      </div>
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm font-medium text-slate-900 ${task.completed ? 'line-through text-slate-400' : ''}`}>
                        {task.title}
                      </p>
                      {task.description && (
                        <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{task.description}</p>
                      )}
                      {task.sourceEmailSubject && (
                        <p className="text-[11px] text-blue-600 mt-1 flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          <span className="truncate">Source: {task.sourceEmailSubject}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <span
                      className={`px-2 py-0.5 text-[11px] font-semibold rounded-md border ${
                        task.priority === 'Urgent'
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : task.priority === 'High'
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-blue-50 text-blue-700 border-blue-200'
                      }`}
                    >
                      {task.priority}
                    </span>
                    <span className="text-[11px] font-medium text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{task.deadline}</span>
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* AI Category Distribution & Analytics */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span>Category Breakdown</span>
            </h2>
            <p className="text-xs text-slate-500">Distribution of emails classified by Gemini</p>
          </div>

          {/* Progress / Distribution Bars */}
          <div className="space-y-3">
            {[
              { label: 'Academic & Courses', cat: 'Academic' as Category, count: categoryCounts.Academic, color: 'bg-indigo-600', icon: GraduationCap },
              { label: 'Work & Internships', cat: 'Work' as Category, count: categoryCounts.Work, color: 'bg-sky-500', icon: Briefcase },
              { label: 'Urgent & Critical', cat: 'Urgent' as Category, count: categoryCounts.Urgent, color: 'bg-rose-500', icon: AlertOctagon },
              { label: 'Personal & Social', cat: 'Personal' as Category, count: categoryCounts.Personal, color: 'bg-emerald-500', icon: User },
              { label: 'Promotional & Deals', cat: 'Promotional' as Category, count: categoryCounts.Promotional, color: 'bg-purple-500', icon: Tag },
            ].map((item) => {
              const percentage = totalEmails > 0 ? Math.round((item.count / totalEmails) * 100) : 0;
              const Icon = item.icon;
              return (
                <div
                  key={item.cat}
                  onClick={() => onNavigateToTab('emails', item.cat)}
                  className="p-2 rounded-lg hover:bg-slate-50 transition cursor-pointer group"
                >
                  <div className="flex items-center justify-between text-xs font-semibold mb-1">
                    <span className="flex items-center gap-1.5 text-slate-700">
                      <Icon className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600" />
                      <span>{item.label}</span>
                    </span>
                    <span className="text-slate-500">
                      {item.count} <span className="text-[10px] text-slate-400 font-normal">({percentage}%)</span>
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full transition-all duration-500`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Task Completion Progress Meter */}
          <div className="pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
              <span>Overall Task Completion</span>
              <span className="text-blue-600 font-bold">{completedTasks} of {tasks.length} ({taskCompletionRate}%)</span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${taskCompletionRate}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Emails Table / List */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Mail className="w-4 h-4 text-blue-600" />
              <span>Recent Incoming Communications</span>
            </h2>
            <p className="text-xs text-slate-500">Latest analyzed emails with summaries and one-click action</p>
          </div>
          <button
            onClick={() => onNavigateToTab('emails', 'All')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>View all inbox</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {recentEmails.map((email) => (
            <div
              key={email.id}
              onClick={() => onSelectEmail(email)}
              className="py-3 px-2 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-50 rounded-lg transition cursor-pointer group"
            >
              <div className="flex items-start gap-3 min-w-0 flex-1">
                {/* Sender Avatar */}
                <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0">
                  {email.sender.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-slate-900">{email.sender}</span>
                    <span className="text-[11px] text-slate-400">·</span>
                    <span className="text-[11px] text-slate-500">
                      {new Date(email.date).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {!email.read && (
                      <span className="w-2 h-2 rounded-full bg-blue-600" title="Unread" />
                    )}
                  </div>
                  <p className="text-sm font-semibold text-slate-800 truncate mt-0.5 group-hover:text-blue-600 transition">
                    {email.subject}
                  </p>
                  {email.aiSummary?.summary ? (
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5 flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-blue-500 shrink-0" />
                      <span>{email.aiSummary.summary}</span>
                    </p>
                  ) : (
                    <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{email.body.slice(0, 90)}...</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                {/* Category Badge */}
                <span
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md border ${
                    email.category === 'Academic'
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                      : email.category === 'Work'
                      ? 'bg-sky-50 text-sky-700 border-sky-200'
                      : email.category === 'Urgent'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : email.category === 'Personal'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-purple-50 text-purple-700 border-purple-200'
                  }`}
                >
                  {email.category}
                </span>

                {email.replyStatus === 'Sent (Demo)' && (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-md border border-emerald-300">
                    Replied (Demo)
                  </span>
                )}

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectEmail(email);
                  }}
                  className="px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-blue-600 hover:text-white rounded-md text-slate-700 transition flex items-center gap-1"
                >
                  <span>AI Actions</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
