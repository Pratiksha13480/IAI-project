import React, { useState } from 'react';
import {
  X,
  Code2,
  Terminal,
  Copy,
  Check,
  FolderGit2,
  Sparkles,
  Layers,
  ShieldCheck,
  ExternalLink,
  BookOpen,
} from 'lucide-react';

interface VSCodeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VSCodeGuideModal: React.FC<VSCodeGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-blue-700 to-indigo-800 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-xs">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                Run SmartMail AI in VS Code
              </h2>
              <p className="text-xs text-blue-100">
                Beginner-friendly developer guide for Computer Science students
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-slate-800 text-sm">
          {/* Quick Overview */}
          <div className="p-4 bg-blue-50/70 border border-blue-200/80 rounded-xl space-y-2">
            <div className="flex items-center gap-2 font-bold text-blue-900 text-xs sm:text-sm">
              <BookOpen className="w-4 h-4 text-blue-700" />
              <span>Zero-Cost & Free-Tier Architecture</span>
            </div>
            <p className="text-xs text-blue-800 leading-relaxed">
              This application is designed specifically for students and beginner developers. It uses 
              <strong> IndexedDB</strong> for persistent local database storage (requiring <strong>zero paid databases</strong>) and 
              <strong> Google Gemini 3.8 Flash</strong> for AI processing. Even without an API key, it runs in full offline Demo Mode.
            </p>
          </div>

          {/* Step 1: Download / Export Source Code */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                1
              </span>
              <span>Download & Extract the Project</span>
            </h3>
            <p className="text-xs text-slate-600 pl-7 leading-relaxed">
              Download the repository files as a ZIP or clone it from your GitHub repo into your local projects directory:
            </p>
            <div className="pl-7">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono relative flex items-center justify-between">
                <span>git clone &lt;your-repo-url&gt; smartmail-ai && cd smartmail-ai</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      'git clone <your-repo-url> smartmail-ai && cd smartmail-ai',
                      'clone'
                    )
                  }
                  className="text-slate-400 hover:text-white transition ml-2"
                >
                  {copiedSnippet === 'clone' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Step 2: Open in VS Code */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                2
              </span>
              <span>Open in Visual Studio Code</span>
            </h3>
            <p className="text-xs text-slate-600 pl-7 leading-relaxed">
              Launch Visual Studio Code and open the project directory via terminal or through <code>File &gt; Open Folder...</code>:
            </p>
            <div className="pl-7">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono relative flex items-center justify-between">
                <span>code .</span>
                <button
                  onClick={() => copyToClipboard('code .', 'code')}
                  className="text-slate-400 hover:text-white transition ml-2"
                >
                  {copiedSnippet === 'code' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Step 3: Install Dependencies */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                3
              </span>
              <span>Install Node.js Dependencies</span>
            </h3>
            <p className="text-xs text-slate-600 pl-7 leading-relaxed">
              Open the integrated terminal in VS Code (<kbd className="px-1 py-0.5 bg-slate-100 border rounded text-[10px]">Ctrl + `</kbd> or <kbd className="px-1 py-0.5 bg-slate-100 border rounded text-[10px]">Cmd + `</kbd>) and run:
            </p>
            <div className="pl-7">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono relative flex items-center justify-between">
                <span>npm install</span>
                <button
                  onClick={() => copyToClipboard('npm install', 'install')}
                  className="text-slate-400 hover:text-white transition ml-2"
                >
                  {copiedSnippet === 'install' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Step 4: Configure .env */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                4
              </span>
              <span>Set Up Environment Variables (.env)</span>
            </h3>
            <p className="text-xs text-slate-600 pl-7 leading-relaxed">
              Create a file named <code>.env</code> in the project root based on <code>.env.example</code>:
            </p>
            <div className="pl-7 space-y-2">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono relative flex items-center justify-between">
                <div>
                  <p className="text-slate-400"># Free API key from Google AI Studio (aistudio.google.com)</p>
                  <p>GEMINI_API_KEY="your-gemini-api-key-here"</p>
                </div>
                <button
                  onClick={() =>
                    copyToClipboard(
                      'GEMINI_API_KEY="your-gemini-api-key-here"',
                      'env'
                    )
                  }
                  className="text-slate-400 hover:text-white transition ml-2"
                >
                  {copiedSnippet === 'env' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                <em>Tip:</em> If you don't provide an API key, the app gracefully runs in <strong>Intelligent Demo Mode</strong> using built-in parsing heuristics.
              </p>
            </div>
          </div>

          {/* Step 5: Run the Development Server */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">
                5
              </span>
              <span>Launch the Development Server</span>
            </h3>
            <p className="text-xs text-slate-600 pl-7 leading-relaxed">
              Start the Vite dev server with server-side Gemini API endpoints enabled:
            </p>
            <div className="pl-7 space-y-2">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono relative flex items-center justify-between">
                <span>npm run dev</span>
                <button
                  onClick={() => copyToClipboard('npm run dev', 'dev')}
                  className="text-slate-400 hover:text-white transition ml-2"
                >
                  {copiedSnippet === 'dev' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-xs text-slate-600">
                Open <a href="http://localhost:3000" target="_blank" rel="noreferrer" className="text-blue-600 font-semibold underline">http://localhost:3000</a> in your browser.
              </p>
            </div>
          </div>

          {/* Architecture Summary */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-600" />
              <span>Project Architecture (Quick Reference for CS Students)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-600">
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <p className="font-bold text-slate-900">Frontend</p>
                <p className="text-[11px] text-slate-500 mt-0.5">React 19, TypeScript, Tailwind CSS v4, Lucide icons</p>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <p className="font-bold text-slate-900">Database</p>
                <p className="text-[11px] text-slate-500 mt-0.5">IndexedDB + LocalStorage (Zero setup, offline persistent)</p>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-slate-200">
                <p className="font-bold text-slate-900">AI Engine</p>
                <p className="text-[11px] text-slate-500 mt-0.5">@google/genai SDK, gemini-3.8-flash, secure server-side proxy</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 flex items-center justify-between bg-slate-50">
          <span className="text-xs text-slate-500">
            Created for third-year CS student developer portfolio & learning
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs transition"
          >
            Got It!
          </button>
        </div>
      </div>
    </div>
  );
};
