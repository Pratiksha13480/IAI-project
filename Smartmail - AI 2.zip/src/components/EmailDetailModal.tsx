import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Calendar,
  Clock,
  CheckCircle2,
  Copy,
  Check,
  Send,
  Plus,
  RefreshCw,
  ShieldAlert,
  User,
  GraduationCap,
  Briefcase,
  AlertOctagon,
  Tag,
  Mail,
  Edit3,
} from 'lucide-react';
import { Email, Task, ReplyDraft, SentReply } from '../types';
import { requestEmailAnalysis, requestSmartReply } from '../services/geminiClient';
import { saveEmail } from '../services/storage';

interface EmailDetailModalProps {
  email: Email | null;
  onClose: () => void;
  onUpdateEmail: (email: Email) => void;
  onAddTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  existingTasks: Task[];
}

export const EmailDetailModal: React.FC<EmailDetailModalProps> = ({
  email,
  onClose,
  onUpdateEmail,
  onAddTask,
  existingTasks,
}) => {
  if (!email) return null;

  const [activeTab, setActiveTab] = useState<'summary' | 'tasks' | 'reply'>('summary');
  const [selectedTone, setSelectedTone] = useState<
    'professional' | 'friendly' | 'formal-academic' | 'polite-decline' | 'short-acknowledgement'
  >(email.category === 'Academic' ? 'formal-academic' : 'professional');
  const [userReplyNotes, setUserReplyNotes] = useState('');
  const [draftReply, setDraftReply] = useState<string>('');
  const [draftSubject, setDraftSubject] = useState<string>(`Re: ${email.subject}`);
  const [isGeneratingReply, setIsGeneratingReply] = useState(false);
  const [isAnalyzingEmail, setIsAnalyzingEmail] = useState(false);
  const [copied, setCopied] = useState(false);
  const [replyStatus, setReplyStatus] = useState<string | null>(email.replyStatus || null);
  const [demoSentMessage, setDemoSentMessage] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [addedTaskTitles, setAddedTaskTitles] = useState<string[]>([]);

  // Sync state if email prop updates
  React.useEffect(() => {
    setReplyStatus(email.replyStatus || null);
    setDraftSubject(`Re: ${email.subject}`);
    setValidationError(null);
  }, [email.id, email.replyStatus, email.subject]);

  // Check if a task from this email is already added in the global task list
  const isTaskAlreadyAdded = (title: string) => {
    return (
      addedTaskTitles.includes(title) ||
      existingTasks.some((t) => t.sourceEmailId === email.id && t.title.toLowerCase() === title.toLowerCase())
    );
  };

  // Re-run AI analysis on this email
  const handleReanalyzeWithAI = async () => {
    setIsAnalyzingEmail(true);
    try {
      const result = await requestEmailAnalysis({
        sender: email.sender,
        subject: email.subject,
        body: email.body,
        receivedAt: email.date,
      });

      const updatedEmail: Email = {
        ...email,
        category: result.category,
        priority: result.priority,
        aiSummary: {
          summary: result.summary,
          keyPoints: result.keyPoints,
          sentiment: result.sentiment,
          confidence: result.confidence,
          modelUsed: result.modelUsed,
          analyzedAt: new Date().toISOString(),
        },
      };

      onUpdateEmail(updatedEmail);

      // If suggested replies returned, pre-fill
      if (result.suggestedReplies && result.suggestedReplies.length > 0) {
        setDraftReply(result.suggestedReplies[0].body);
      }
    } catch (err) {
      console.error('Failed to re-analyze email', err);
    } finally {
      setIsAnalyzingEmail(false);
    }
  };

  // Generate Smart Reply
  const handleGenerateReply = async () => {
    setIsGeneratingReply(true);
    try {
      const res = await requestSmartReply({
        email: {
          sender: email.sender,
          subject: email.subject,
          body: email.body,
        },
        tone: selectedTone,
        userNotes: userReplyNotes,
      });

      setDraftReply(res.replyBody);
      setDraftSubject(res.subject);
    } catch (err) {
      console.error('Smart reply error', err);
    } finally {
      setIsGeneratingReply(false);
    }
  };

  // Copy Draft to Clipboard
  const handleCopyDraft = async () => {
    if (!draftReply) return;
    try {
      await navigator.clipboard.writeText(draftReply);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  // Send Reply in Demo Mode (Simulated, no real email sent, no Gmail connection)
  const handleSendDemoReply = async () => {
    setValidationError(null);
    const trimmedReply = draftReply.trim();
    if (!trimmedReply) {
      setValidationError('Reply cannot be empty. Please enter or generate a reply draft before sending.');
      return;
    }

    const confirmed = window.confirm(
      `Send simulated reply to "${email.sender}" in Demo Mode?\n\nRecipient: ${email.senderEmail}\nSubject: ${draftSubject}\n\nNotice: This action simulates sending within Demo Mode. Real emails are never sent automatically and no external Gmail connection is made.`
    );

    if (!confirmed) return;

    const nowIso = new Date().toISOString();
    const newReply: SentReply = {
      id: `reply-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      emailId: email.id,
      sender: 'Me',
      senderEmail: 'student@university.edu',
      recipient: email.sender,
      recipientEmail: email.senderEmail,
      subject: draftSubject || `Re: ${email.subject}`,
      body: trimmedReply,
      sentAt: nowIso,
      tone: selectedTone,
      status: 'Sent (Demo)',
    };

    const updatedReplies = [...(email.sentReplies || []), newReply];
    const updatedEmail: Email = {
      ...email,
      replyStatus: 'Sent (Demo)',
      sentReplies: updatedReplies,
    };

    setReplyStatus('Sent (Demo)');
    setDemoSentMessage('Reply sent successfully in Demo Mode');
    setValidationError(null);
    setDraftReply(''); // Clear draft textarea for next message

    // Commit to IndexedDB storage
    await saveEmail(updatedEmail);

    // Update parent state and current view
    onUpdateEmail(updatedEmail);
  };

  // Add individual extracted task
  const handleAddExtractedTask = (title: string, deadline: string, priority: Task['priority']) => {
    onAddTask({
      title,
      description: `Extracted from email: ${email.subject}`,
      deadline: deadline || 'Upcoming',
      priority: priority || email.priority,
      category: email.category,
      completed: false,
      sourceEmailId: email.id,
      sourceEmailSubject: email.subject,
    });
    setAddedTaskTitles((prev) => [...prev, title]);
  };

  // Format date
  const formattedDate = new Date(email.date).toLocaleString(undefined, {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-start justify-between gap-4 bg-slate-50/70">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span
                className={`px-2.5 py-0.5 text-xs font-semibold rounded-md border ${
                  email.category === 'Academic'
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                    : email.category === 'Work'
                    ? 'bg-sky-50 text-sky-700 border-sky-200'
                    : email.category === 'Urgent'
                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                    : email.category === 'Personal'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-purple-50 text-purple-700 border-purple-200'
                }`}
              >
                {email.category}
              </span>

              <span
                className={`px-2 py-0.5 text-[11px] font-semibold rounded border ${
                  email.priority === 'Urgent'
                    ? 'bg-rose-100 text-rose-800 border-rose-300 font-bold'
                    : email.priority === 'High'
                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                    : 'bg-blue-50 text-blue-800 border-blue-200'
                }`}
              >
                Priority: {email.priority}
              </span>

              {email.aiSummary?.modelUsed && (
                <span className="text-[11px] font-medium text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-blue-500" />
                  <span>{email.aiSummary.modelUsed}</span>
                </span>
              )}
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight leading-snug">
              {email.subject}
            </h2>

            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 flex-wrap">
              <span className="font-semibold text-slate-700">{email.sender}</span>
              <span>&lt;{email.senderEmail}&gt;</span>
              <span>·</span>
              <span>{formattedDate}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReanalyzeWithAI}
              disabled={isAnalyzingEmail}
              className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition border border-slate-200 flex items-center gap-1 text-xs font-medium"
              title="Re-run AI Analysis with Gemini"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzingEmail ? 'animate-spin text-blue-600' : ''}`} />
              <span className="hidden sm:inline">{isAnalyzingEmail ? 'Analyzing...' : 'Re-Analyze'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Split into Original Email View + AI Intelligence Hub */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Left Column: Conversation Thread (7 cols on lg) */}
          <div className="lg:col-span-7 p-5 space-y-4 overflow-y-auto">
            <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-1.5 font-bold text-slate-700">
                <Mail className="w-4 h-4 text-blue-600" />
                <span>Conversation Thread</span>
                <span className="text-[11px] font-normal text-slate-500">
                  ({1 + (email.sentReplies?.length || 0)} message{1 + (email.sentReplies?.length || 0) > 1 ? 's' : ''})
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-medium">Stored in IndexedDB</span>
            </div>

            {/* Message 1: Original Incoming Email Card */}
            <div className="bg-slate-50/90 rounded-xl border border-slate-200 p-4 space-y-3 shadow-2xs">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0">
                    {email.sender.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-bold text-slate-900">{email.sender}</span>
                      <span className="text-[11px] text-slate-500">&lt;{email.senderEmail}&gt;</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">To: {email.recipient}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] text-slate-500 font-medium">{formattedDate}</span>
                </div>
              </div>

              <div className="text-slate-800 whitespace-pre-wrap font-sans text-sm leading-relaxed pt-2 border-t border-slate-200/80">
                {email.body}
              </div>
            </div>

            {/* Sent Replies Thread (Simulated Demo Replies) */}
            {email.sentReplies && email.sentReplies.length > 0 && (
              <div className="space-y-4 pt-2">
                <div className="relative flex items-center justify-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-blue-200" />
                  </div>
                  <span className="relative bg-white px-3 text-[11px] font-bold text-blue-700 uppercase tracking-wider flex items-center gap-1.5 border border-blue-100 rounded-full py-0.5 shadow-2xs">
                    <Send className="w-3 h-3 text-blue-600" />
                    <span>Replies ({email.sentReplies.length})</span>
                  </span>
                </div>

                {email.sentReplies.map((reply, index) => {
                  const replyDateFormatted = new Date(reply.sentAt).toLocaleString(undefined, {
                    weekday: 'short',
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div
                      key={reply.id || index}
                      className="bg-blue-50/60 rounded-xl border border-blue-200 p-4 space-y-3 shadow-2xs ml-3 sm:ml-6 relative border-l-4 border-l-blue-600 animate-in fade-in slide-in-from-bottom-2 duration-200"
                    >
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-2.5">
                          {/* Sender: Me Avatar */}
                          <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
                            Me
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-bold text-slate-900">Me</span>
                              <span className="text-[11px] text-slate-500">&lt;student@university.edu&gt;</span>
                              <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-md border border-emerald-300 flex items-center gap-1">
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span>Sent (Demo)</span>
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              To: {reply.recipient} &lt;{reply.recipientEmail}&gt;
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[11px] text-slate-600 font-medium flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{replyDateFormatted}</span>
                          </span>
                        </div>
                      </div>

                      {/* Reply Message Body */}
                      <div className="text-slate-800 whitespace-pre-wrap font-sans text-sm leading-relaxed pt-2 border-t border-blue-200/60 bg-white/80 p-3.5 rounded-lg border border-blue-100">
                        {reply.body}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                        <span className="text-slate-500 font-medium">
                          Subject: {reply.subject}
                        </span>
                        <span className="text-emerald-700 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Delivered in Demo Mode</span>
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Empty state when no replies sent yet */}
            {(!email.sentReplies || email.sentReplies.length === 0) && (
              <div className="p-3.5 border border-dashed border-slate-300 bg-slate-50/50 rounded-xl text-center text-xs text-slate-500 space-y-1">
                <p className="font-semibold text-slate-700">No replies sent yet</p>
                <p className="text-[11px] text-slate-400">
                  Select a tone on the right and click "Send Reply (Demo)" to simulate an answer in this thread.
                </p>
              </div>
            )}
          </div>

          {/* Right Column: AI Intelligence & Actions (5 cols on lg) */}
          <div className="lg:col-span-5 flex flex-col bg-slate-50/40">
            {/* Tabs for AI Features */}
            <div className="flex items-center border-b border-slate-200 bg-white px-3 pt-2">
              <button
                onClick={() => setActiveTab('summary')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition ${
                  activeTab === 'summary'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Summary</span>
              </button>

              <button
                onClick={() => setActiveTab('tasks')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition ${
                  activeTab === 'tasks'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Extracted Tasks</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('reply');
                  if (!draftReply) {
                    handleGenerateReply();
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition ${
                  activeTab === 'reply'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>Smart Reply</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-4 flex-1 overflow-y-auto space-y-4">
              {/* TAB 1: AI Summary */}
              {activeTab === 'summary' && (
                <div className="space-y-4">
                  {/* Summary Box */}
                  <div className="bg-white p-4 rounded-xl border border-blue-100 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-700 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                        <span>Executive Summary</span>
                      </span>
                      {email.aiSummary?.sentiment && (
                        <span className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                          {email.aiSummary.sentiment}
                        </span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                      {email.aiSummary?.summary || 'No summary generated yet. Click Re-Analyze to run Gemini AI.'}
                    </p>
                  </div>

                  {/* Key Takeaways */}
                  {email.aiSummary?.keyPoints && email.aiSummary.keyPoints.length > 0 && (
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <span className="text-xs font-bold text-slate-800">Key Takeaways</span>
                      <ul className="space-y-1.5">
                        {email.aiSummary.keyPoints.map((point, idx) => (
                          <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Quick Action Button to Jump to Smart Reply */}
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setActiveTab('reply');
                        if (!draftReply) handleGenerateReply();
                      }}
                      className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition flex items-center justify-center gap-2 shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Draft Smart Reply with AI</span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: Task Extraction */}
              {activeTab === 'tasks' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">Action Items & Deadlines</span>
                    <span className="text-[11px] text-slate-400">Identified from text</span>
                  </div>

                  {/* List of Tasks extracted from this email */}
                  {existingTasks.filter((t) => t.sourceEmailId === email.id).length > 0 ? (
                    <div className="space-y-2">
                      {existingTasks
                        .filter((t) => t.sourceEmailId === email.id)
                        .map((task) => (
                          <div
                            key={task.id}
                            className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs flex items-start justify-between gap-2"
                          >
                            <div>
                              <p className={`text-xs font-semibold ${task.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                                {task.title}
                              </p>
                              <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-slate-400" />
                                  <span>{task.deadline}</span>
                                </span>
                                <span>·</span>
                                <span className="text-blue-600 font-medium">{task.priority}</span>
                              </div>
                            </div>
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              Added
                            </span>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="bg-white p-4 rounded-xl border border-slate-200 text-center space-y-2">
                      <p className="text-xs text-slate-500">No tasks currently linked to this email.</p>
                      <button
                        onClick={() =>
                          handleAddExtractedTask(
                            `Follow up on: ${email.subject}`,
                            'Upcoming',
                            email.priority
                          )
                        }
                        className="px-3 py-1.5 text-xs font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg transition inline-flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Default Follow-up Task</span>
                      </button>
                    </div>
                  )}

                  {/* Manual add task shortcut */}
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        const title = prompt('Enter new task title for this email:');
                        if (title?.trim()) {
                          const deadline = prompt('Enter deadline (e.g. Tomorrow 5 PM, Friday):') || 'Upcoming';
                          handleAddExtractedTask(title.trim(), deadline, email.priority);
                        }
                      }}
                      className="w-full py-2 border border-dashed border-slate-300 hover:border-blue-400 hover:bg-blue-50/50 text-slate-600 hover:text-blue-700 rounded-lg text-xs font-medium transition flex items-center justify-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Custom Action Item</span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 3: Smart Reply Studio */}
              {activeTab === 'reply' && (
                <div className="space-y-3.5">
                  {/* Tone Selector */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1.5">
                      Select Response Tone:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {[
                        { id: 'professional', label: 'Professional' },
                        { id: 'formal-academic', label: 'Academic / Student' },
                        { id: 'friendly', label: 'Friendly' },
                        { id: 'short-acknowledgement', label: 'Quick Ack' },
                        { id: 'polite-decline', label: 'Polite Decline' },
                      ].map((t) => (
                        <button
                          key={t.id}
                          onClick={() => setSelectedTone(t.id as any)}
                          className={`px-2.5 py-1.5 text-xs font-medium rounded-md border text-center transition ${
                            selectedTone === t.id
                              ? 'bg-blue-600 text-white border-blue-600 font-semibold'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom instructions / notes input */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">
                      Key points to include (optional):
                    </label>
                    <input
                      type="text"
                      value={userReplyNotes}
                      onChange={(e) => setUserReplyNotes(e.target.value)}
                      placeholder="e.g., I'm available Tuesday 2pm, attached my updated resume"
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
                    />
                  </div>

                  {/* Generate Button */}
                  <button
                    onClick={handleGenerateReply}
                    disabled={isGeneratingReply}
                    className="w-full py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isGeneratingReply ? 'animate-spin' : ''}`} />
                    <span>{isGeneratingReply ? 'Gemini is drafting reply...' : 'Generate Reply Draft'}</span>
                  </button>

                  {/* Editable Draft View */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs flex-wrap gap-2">
                      <div className="flex items-center gap-1.5">
                        <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                        <span className="font-bold text-slate-700">Editable Reply Draft</span>
                        {replyStatus === 'Sent (Demo)' && (
                          <span className="ml-1 px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-md border border-emerald-300 flex items-center gap-1">
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>Sent (Demo)</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Copy Reply Button */}
                        <button
                          type="button"
                          onClick={handleCopyDraft}
                          disabled={!draftReply}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-blue-700 hover:bg-slate-100 border border-slate-200 rounded-md transition flex items-center gap-1 disabled:opacity-40"
                          title="Copy reply text to clipboard"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span className="text-emerald-600 font-bold">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy Draft</span>
                            </>
                          )}
                        </button>

                        {/* Send Reply (Demo) Button */}
                        <button
                          type="button"
                          onClick={handleSendDemoReply}
                          className="px-3 py-1 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-md transition flex items-center gap-1.5 shadow-2xs"
                          title="Simulate sending reply in Demo Mode without connecting Gmail"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Reply (Demo)</span>
                        </button>
                      </div>
                    </div>

                    {/* Validation Error Banner */}
                    {validationError && (
                      <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs flex items-center justify-between">
                        <span>{validationError}</span>
                        <button
                          type="button"
                          onClick={() => setValidationError(null)}
                          className="text-rose-500 hover:text-rose-700 font-bold ml-2 text-xs"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    {/* Demo Sent Success Alert */}
                    {demoSentMessage && (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between gap-2 text-xs text-emerald-900 shadow-2xs animate-in fade-in duration-150">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <p className="font-bold text-emerald-900">Reply sent successfully in Demo Mode</p>
                            <p className="text-[11px] text-emerald-700">Simulated delivery recorded in your local workspace. Real external emails are never sent.</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setDemoSentMessage(null)}
                          className="text-emerald-700 hover:text-emerald-900 p-1 text-xs font-bold"
                          title="Dismiss"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    <textarea
                      value={draftReply}
                      onChange={(e) => {
                        setDraftReply(e.target.value);
                        if (validationError) setValidationError(null);
                      }}
                      rows={6}
                      placeholder="Click 'Generate Reply Draft' above to draft response..."
                      className="w-full p-3 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-slate-800 leading-relaxed resize-none"
                    />
                  </div>

                  {/* Safety Notice */}
                  <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 flex items-start gap-2 text-[11px] text-amber-800">
                    <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>
                      <strong>Safety Guarantee:</strong> SmartMail AI never sends emails automatically. You retain full control to edit and review drafts before simulating.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 px-5 bg-white border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-400">Press ESC or click close to dismiss</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
