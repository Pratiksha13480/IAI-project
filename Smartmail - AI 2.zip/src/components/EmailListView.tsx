import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Sparkles,
  Star,
  Trash2,
  Mail,
  MailOpen,
  Calendar,
  AlertCircle,
  GraduationCap,
  Briefcase,
  AlertOctagon,
  User,
  Tag,
  CheckCircle2,
  Clock,
  ArrowUpDown,
  PlusCircle,
} from 'lucide-react';
import { Email, Category, Priority } from '../types';

interface EmailListViewProps {
  emails: Email[];
  selectedCategory: Category | 'All';
  setSelectedCategory: (cat: Category | 'All') => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectEmail: (email: Email) => void;
  onToggleStar: (emailId: string) => void;
  onToggleRead: (emailId: string) => void;
  onDeleteEmail: (emailId: string) => void;
  onOpenNewEmailModal: () => void;
}

export const EmailListView: React.FC<EmailListViewProps> = ({
  emails,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  onSearchChange,
  onSelectEmail,
  onToggleStar,
  onToggleRead,
  onDeleteEmail,
  onOpenNewEmailModal,
}) => {
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'All'>('All');
  const [readFilter, setReadFilter] = useState<'All' | 'Unread' | 'Starred'>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'priority'>('newest');

  // Filtered and sorted emails
  const filteredEmails = useMemo(() => {
    return emails
      .filter((email) => {
        // Category filter
        if (selectedCategory !== 'All' && email.category !== selectedCategory) {
          return false;
        }
        // Priority filter
        if (priorityFilter !== 'All' && email.priority !== priorityFilter) {
          return false;
        }
        // Read filter
        if (readFilter === 'Unread' && email.read) {
          return false;
        }
        if (readFilter === 'Starred' && !email.starred) {
          return false;
        }
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchSender = email.sender.toLowerCase().includes(q);
          const matchSubject = email.subject.toLowerCase().includes(q);
          const matchBody = email.body.toLowerCase().includes(q);
          const matchSummary = email.aiSummary?.summary.toLowerCase().includes(q);
          if (!matchSender && !matchSubject && !matchBody && !matchSummary) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        }
        if (sortBy === 'oldest') {
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        }
        if (sortBy === 'priority') {
          const pOrder: Record<Priority, number> = { Urgent: 0, High: 1, Medium: 2, Low: 3 };
          return pOrder[a.priority] - pOrder[b.priority];
        }
        return 0;
      });
  }, [emails, selectedCategory, priorityFilter, readFilter, searchQuery, sortBy]);

  const categories: Array<{ id: Category | 'All'; label: string; icon?: React.ElementType }> = [
    { id: 'All', label: 'All Emails' },
    { id: 'Academic', label: 'Academic', icon: GraduationCap },
    { id: 'Work', label: 'Work', icon: Briefcase },
    { id: 'Urgent', label: 'Urgent', icon: AlertOctagon },
    { id: 'Personal', label: 'Personal', icon: User },
    { id: 'Promotional', label: 'Promotional', icon: Tag },
  ];

  return (
    <div className="space-y-4">
      {/* Top Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((c) => {
            const isSelected = selectedCategory === c.id;
            const Icon = c.icon;
            const count =
              c.id === 'All'
                ? emails.length
                : emails.filter((e) => e.category === c.id).length;

            return (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg shrink-0 transition ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {Icon && <Icon className="w-3.5 h-3.5" />}
                <span>{c.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-blue-700 text-blue-100' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Secondary Filter & Sort controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            {/* Priority Filter */}
            <div className="flex items-center gap-1 text-slate-500">
              <Filter className="w-3.5 h-3.5" />
              <span className="font-medium">Priority:</span>
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="All">All Priorities</option>
                <option value="Urgent">Urgent</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            {/* Read / Starred Status */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg">
              {(['All', 'Unread', 'Starred'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setReadFilter(mode)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition ${
                    readFilter === mode ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 text-slate-500">
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="newest">Newest first</option>
                <option value="oldest">Oldest first</option>
                <option value="priority">Priority highest</option>
              </select>
            </div>

            {/* Quick Email Simulation */}
            <button
              onClick={onOpenNewEmailModal}
              className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Simulate Mail</span>
            </button>
          </div>
        </div>
      </div>

      {/* Email List View */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs divide-y divide-slate-100 overflow-hidden">
        {filteredEmails.length === 0 ? (
          <div className="py-16 text-center text-slate-500 space-y-3">
            <Mail className="w-12 h-12 mx-auto text-slate-300" />
            <div>
              <p className="text-base font-semibold text-slate-800">No emails match the selected filters</p>
              <p className="text-xs text-slate-400 mt-1">Try resetting the search terms or category selection</p>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setPriorityFilter('All');
                setReadFilter('All');
                onSearchChange('');
              }}
              className="px-3.5 py-1.5 text-xs font-semibold bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition"
            >
              Reset all filters
            </button>
          </div>
        ) : (
          filteredEmails.map((email) => (
            <div
              key={email.id}
              onClick={() => onSelectEmail(email)}
              className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-blue-50/40 transition cursor-pointer group ${
                !email.read ? 'bg-blue-50/20' : 'bg-white'
              }`}
            >
              {/* Left Column: Star, Avatar, Sender, Subject, Summary */}
              <div className="flex items-start gap-3 min-w-0 flex-1">
                {/* Star Icon */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleStar(email.id);
                  }}
                  className="mt-0.5 text-slate-300 hover:text-amber-400 transition"
                  title={email.starred ? 'Starred' : 'Not starred'}
                >
                  <Star
                    className={`w-4 h-4 ${
                      email.starred ? 'text-amber-400 fill-amber-400' : 'text-slate-300'
                    }`}
                  />
                </button>

                {/* Sender Avatar */}
                <div
                  className={`w-9 h-9 rounded-full font-bold text-xs flex items-center justify-center shrink-0 ${
                    email.category === 'Urgent'
                      ? 'bg-rose-100 text-rose-700'
                      : email.category === 'Academic'
                      ? 'bg-indigo-100 text-indigo-700'
                      : email.category === 'Work'
                      ? 'bg-sky-100 text-sky-700'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {email.sender.slice(0, 2).toUpperCase()}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs ${!email.read ? 'font-bold text-slate-900' : 'font-semibold text-slate-700'}`}>
                      {email.sender}
                    </span>
                    <span className="text-[11px] text-slate-400">&lt;{email.senderEmail}&gt;</span>
                    <span className="text-[11px] text-slate-400">·</span>
                    <span className="text-[11px] text-slate-500">
                      {new Date(email.date).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {!email.read && (
                      <span className="px-1.5 py-0.2 text-[10px] font-bold bg-blue-600 text-white rounded">
                        NEW
                      </span>
                    )}
                  </div>

                  {/* Subject */}
                  <h3 className={`text-sm mt-0.5 truncate group-hover:text-blue-600 transition ${
                    !email.read ? 'font-bold text-slate-900' : 'font-medium text-slate-800'
                  }`}>
                    {email.subject}
                  </h3>

                  {/* AI Summary Highlight */}
                  {email.aiSummary?.summary ? (
                    <div className="mt-1 flex items-start gap-1.5 text-xs text-slate-600 bg-slate-50/80 p-2 rounded-md border border-slate-100">
                      <Sparkles className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                      <p className="line-clamp-2 leading-relaxed">
                        <span className="font-semibold text-slate-700">AI Summary: </span>
                        {email.aiSummary.summary}
                      </p>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{email.body.slice(0, 110)}...</p>
                  )}
                </div>
              </div>

              {/* Right Column: Category Badge, Priority Badge, Quick Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                {/* Category Badge */}
                <span
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md border ${
                    email.category === 'Academic'
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                      : email.category === 'Work'
                      ? 'bg-sky-50 text-sky-700 border-sky-200'
                      : email.category === 'Urgent'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : email.category === 'Personal'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-purple-50 text-purple-700 border-purple-200'
                  }`}
                >
                  {email.category}
                </span>

                {/* Priority Badge */}
                <span
                  className={`px-2 py-0.5 text-[11px] font-semibold rounded border ${
                    email.priority === 'Urgent'
                      ? 'bg-rose-100 text-rose-800 border-rose-300 font-bold'
                      : email.priority === 'High'
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : email.priority === 'Medium'
                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                      : 'bg-slate-100 text-slate-600 border-slate-200'
                  }`}
                >
                  {email.priority}
                </span>

                {/* Sent (Demo) Status Badge */}
                {email.replyStatus === 'Sent (Demo)' && (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-md border border-emerald-300 flex items-center gap-1">
                    Replied (Demo)
                  </span>
                )}

                {/* Mark Read/Unread Icon */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleRead(email.id);
                  }}
                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded transition"
                  title={email.read ? 'Mark as unread' : 'Mark as read'}
                >
                  {email.read ? <Mail className="w-4 h-4" /> : <MailOpen className="w-4 h-4 text-blue-600" />}
                </button>

                {/* Delete Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm(`Delete email "${email.subject}"?`)) {
                      onDeleteEmail(email.id);
                    }
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                  title="Delete email"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
