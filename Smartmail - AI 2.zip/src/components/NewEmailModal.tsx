import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Send,
  Wand2,
  GraduationCap,
  Briefcase,
  AlertOctagon,
  User,
  Tag,
  Mail,
} from 'lucide-react';
import { Email, Task } from '../types';
import { requestEmailAnalysis } from '../services/geminiClient';

interface NewEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEmailCreated: (email: Email, extractedTasks: Task[]) => void;
}

const TEMPLATES = [
  {
    title: 'Academic: Course Assignment Extension & Office Hours',
    sender: 'Prof. Katherine Vance',
    senderEmail: 'kvance@university.edu',
    subject: 'CS310 Algorithms: Problem Set 4 Extension & Solution Discussion',
    body: `Hello CS310 Students,

Due to the university network outage yesterday, I am extending the deadline for Problem Set 4 (Dynamic Programming & Network Flow) to Monday, Nov 5th at 5:00 PM.

Please note:
1. Submit your LaTeX PDF and Python verification scripts via the Gradescope portal before the deadline.
2. Group submissions must list all student IDs in the header.
3. Extra office hours will be held this Friday at 3:00 PM in Computer Science Hall Room 302.

Good luck finishing up the problem sets.

Prof. Katherine Vance`,
  },
  {
    title: 'Work: Meta SWE Internship Offer & Decision Deadline',
    sender: 'Jordan Blake (University Recruiting)',
    senderEmail: 'jblake@meta-recruiting.com',
    subject: 'Meta: Offer Update - Software Engineering Internship Summer 2027',
    body: `Hi there,

Congratulations! Following your final technical interviews last week, we are thrilled to extend an official offer to join Meta as a Software Engineering Intern for Summer 2027 in Seattle!

Next steps:
- Please review the attached compensation and housing stipend package.
- Sign and return your electronic offer letter via DocuSign by Wednesday, Nov 7th at 5:00 PM PST.
- Fill out the team matching preference survey before next Friday.

Please let me know if you would like to set up a 15-minute call with your prospective engineering manager this week!

Best,
Jordan Blake`,
  },
  {
    title: 'Urgent: AWS Cloud Budget Alert - Immediate Action Required',
    sender: 'AWS Billing & Cost Management',
    senderEmail: 'no-reply-aws@amazon.com',
    subject: 'URGENT: AWS Free Tier Limit Exceeded - 85% of Budget Consumed',
    body: `Dear AWS Customer,

Your AWS account 8291-0394-1102 has exceeded 85% of your Free Tier EC2 compute hours for the current billing cycle.

Immediate Required Action:
- Log in to the AWS Management Console and terminate running g4dn.xlarge GPU instances immediately if not in active use.
- Set up an AWS CloudWatch billing alarm with an SNS notification to prevent unexpected overage charges.
- Verify that your Elastic IP addresses are associated with active instances to avoid unattached IP charges.

Charges will commence automatically if threshold is exceeded within the next 24 hours.`,
  },
  {
    title: 'Personal: Tech Meetup & Hackathon Ride Sharing',
    sender: 'Maya Patel (CS Society)',
    senderEmail: 'maya.patel.cs@gmail.com',
    subject: 'HackNY Ride Sharing & Carpool Coordination this Saturday',
    body: `Hey everyone!

Quick check-in for the carpool to HackNY this Saturday morning:
- We are leaving campus from the student union parking lot at 7:30 AM sharp.
- Please confirm your seat in the group spreadsheet before Thursday night so we know how many cars are needed.
- Bring $10 cash for gas and bridge tolls.

See you all this Saturday!
Maya`,
  },
];

export const NewEmailModal: React.FC<NewEmailModalProps> = ({
  isOpen,
  onClose,
  onEmailCreated,
}) => {
  if (!isOpen) return null;

  const [sender, setSender] = useState('Prof. Katherine Vance');
  const [senderEmail, setSenderEmail] = useState('kvance@university.edu');
  const [subject, setSubject] = useState('CS310 Algorithms: Problem Set 4 Extension');
  const [body, setBody] = useState(
    'Due to the university network outage yesterday, I am extending the deadline for Problem Set 4 to Monday at 5:00 PM.\n\nPlease submit via Gradescope portal and attend extra office hours Friday at 3:00 PM.'
  );
  const [isProcessing, setIsProcessing] = useState(false);

  // Apply template
  const handleApplyTemplate = (tpl: (typeof TEMPLATES)[0]) => {
    setSender(tpl.sender);
    setSenderEmail(tpl.senderEmail);
    setSubject(tpl.subject);
    setBody(tpl.body);
  };

  const handleSimulate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !body.trim()) return;

    setIsProcessing(true);
    try {
      const emailId = `em-${Date.now()}`;
      const nowIso = new Date().toISOString();

      // Trigger Gemini AI Analysis
      const analysis = await requestEmailAnalysis({
        sender: sender.trim() || 'Unknown Sender',
        subject: subject.trim(),
        body: body.trim(),
        receivedAt: nowIso,
      });

      const newEmail: Email = {
        id: emailId,
        sender: sender.trim() || 'Sender',
        senderEmail: senderEmail.trim() || 'sender@example.com',
        recipient: 'student@university.edu',
        subject: subject.trim(),
        body: body.trim(),
        date: nowIso,
        read: false,
        starred: false,
        category: analysis.category,
        priority: analysis.priority,
        aiSummary: {
          summary: analysis.summary,
          keyPoints: analysis.keyPoints,
          sentiment: analysis.sentiment,
          confidence: analysis.confidence,
          modelUsed: analysis.modelUsed,
          analyzedAt: nowIso,
        },
        tasksExtracted: analysis.tasks.length > 0,
      };

      // Create extracted task objects
      const newTasks: Task[] = (analysis.tasks || []).map((t, index) => ({
        id: `task-${Date.now()}-${index}`,
        title: t.title,
        description: t.description || `Extracted from email: ${subject}`,
        deadline: t.deadline || 'Upcoming',
        priority: t.priority,
        category: analysis.category,
        completed: false,
        sourceEmailId: emailId,
        sourceEmailSubject: subject,
        createdAt: nowIso,
      }));

      onEmailCreated(newEmail, newTasks);
      onClose();
    } catch (err) {
      console.error('Error simulating email', err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              <span>Simulate Incoming Email & Run AI</span>
            </h2>
            <p className="text-xs text-slate-500">
              Test SmartMail AI with realistic templates or compose any email content
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Quick Templates */}
          <div>
            <span className="block text-[11px] font-bold uppercase text-slate-400 mb-1.5">
              Quick Realistic Presets:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {TEMPLATES.map((tpl, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleApplyTemplate(tpl)}
                  className="p-2.5 text-left rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 transition text-xs group"
                >
                  <p className="font-semibold text-slate-800 group-hover:text-blue-600 truncate">
                    {tpl.title}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">{tpl.sender}</p>
                </button>
              ))}
            </div>
          </div>

          <form id="simulate-form" onSubmit={handleSimulate} className="space-y-3.5 pt-2 border-t border-slate-100">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Sender Name *
                </label>
                <input
                  type="text"
                  required
                  value={sender}
                  onChange={(e) => setSender(e.target.value)}
                  placeholder="e.g. Prof. David Martinez"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Sender Email *
                </label>
                <input
                  type="email"
                  required
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  placeholder="e.g. professor@university.edu"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Subject Line *
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Final Project Submission Deadline"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Email Content / Body *
              </label>
              <textarea
                rows={5}
                required
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Paste or write email text here..."
                className="w-full p-3 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans text-slate-800 leading-relaxed"
              />
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 flex items-center justify-between bg-slate-50">
          <span className="text-xs text-slate-500">
            SmartMail AI will classify category, extract tasks & generate replies
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              form="simulate-form"
              type="submit"
              disabled={isProcessing}
              className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition shadow-xs flex items-center gap-1.5"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
              <span>{isProcessing ? 'Analyzing with Gemini...' : 'Analyze & Inject Email'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
