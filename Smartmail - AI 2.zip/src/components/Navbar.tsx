import React from 'react';
import { 
  Sparkles, 
  Search, 
  Code2, 
  PlusCircle, 
  RefreshCw,
  Database,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  aiStatus: { available: boolean; model: string; reason?: string };
  onOpenNewEmailModal: () => void;
  onOpenGuideModal: () => void;
  onResetData: () => void;
  activeTab: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  onSearchChange,
  aiStatus,
  onOpenNewEmailModal,
  onOpenGuideModal,
  onResetData,
  activeTab,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search emails, senders, subjects, or tasks..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-slate-800 placeholder-slate-400"
          />
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {/* AI Status Badge */}
          <div 
            title={aiStatus.available ? `Connected to Gemini ${aiStatus.model}` : `Demo/Heuristics mode: ${aiStatus.reason || 'Offline mock mode'}`}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium border ${
              aiStatus.available 
                ? 'bg-blue-50 text-blue-700 border-blue-200' 
                : 'bg-amber-50 text-amber-700 border-amber-200'
            }`}
          >
            {aiStatus.available ? (
              <>
                <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
                <span className="hidden md:inline">Gemini 3.8 Flash Active</span>
                <span className="md:hidden">Gemini AI</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span className="hidden md:inline">Demo Mode (Local Heuristics)</span>
                <span className="md:hidden">Demo Mode</span>
              </>
            )}
          </div>

          {/* Simulate New Email Button */}
          <button
            onClick={onOpenNewEmailModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-sm"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Simulate Incoming Email</span>
          </button>

          {/* Reset Demo Data Button */}
          <button
            onClick={() => {
              if (window.confirm('Reset sample emails and tasks to original defaults?')) {
                onResetData();
              }
            }}
            title="Reset database to default sample data"
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition border border-slate-200"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* VS Code instructions */}
          <button
            onClick={onOpenGuideModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition"
            title="View VS Code project instructions for student developers"
          >
            <Code2 className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">VS Code Run Guide</span>
          </button>
        </div>
      </div>
    </header>
  );
};
