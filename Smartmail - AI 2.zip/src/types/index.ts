export type Category = 'Academic' | 'Work' | 'Personal' | 'Promotional' | 'Urgent';

export type Priority = 'Urgent' | 'High' | 'Medium' | 'Low';

export interface AISummary {
  summary: string;
  keyPoints: string[];
  sentiment: 'Neutral' | 'Action-Required' | 'Informational' | 'Appreciative';
  confidence: number;
  modelUsed: string;
  analyzedAt: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  deadline: string;
  priority: Priority;
  category: Category;
  completed: boolean;
  sourceEmailId?: string;
  sourceEmailSubject?: string;
  createdAt: string;
  completedAt?: string;
}

export interface SentReply {
  id: string;
  emailId: string;
  sender: string; // 'Me'
  senderEmail?: string;
  recipient: string;
  recipientEmail: string;
  subject: string;
  body: string;
  sentAt: string; // ISO string
  tone?: string;
  status: 'Sent (Demo)';
}

export interface Email {
  id: string;
  sender: string;
  senderEmail: string;
  recipient: string;
  subject: string;
  body: string;
  date: string;
  read: boolean;
  starred: boolean;
  category: Category;
  priority: Priority;
  aiSummary?: AISummary;
  tasksExtracted?: boolean;
  replyStatus?: 'Sent (Demo)' | 'Draft' | string;
  sentReplies?: SentReply[];
}

export interface ReplyDraft {
  tone: 'professional' | 'friendly' | 'formal-academic' | 'polite-decline' | 'short-acknowledgement';
  label: string;
  subject: string;
  body: string;
  modelUsed?: string;
}
