import { Email, Task } from '../types';
import { INITIAL_SAMPLE_EMAILS, INITIAL_SAMPLE_TASKS } from '../data/sampleEmails';

const EMAILS_STORAGE_KEY = 'smartmail_ai_emails_v1';
const TASKS_STORAGE_KEY = 'smartmail_ai_tasks_v1';
const DB_VERSION_KEY = 'smartmail_ai_initialized_v1';

// IndexedDB database configuration for structured persistent storage
const DB_NAME = 'SmartMailAIDatabase';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function getIDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('emails')) {
        db.createObjectStore('emails', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('tasks')) {
        db.createObjectStore('tasks', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

// Fallback localStorage helpers
function getFromLocalStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveToLocalStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('LocalStorage save failed:', e);
  }
}

export async function initializeDatabase(): Promise<{ emails: Email[]; tasks: Task[] }> {
  const isInitialized = localStorage.getItem(DB_VERSION_KEY);

  if (!isInitialized) {
    // First run: Seed with rich realistic sample emails & tasks
    await saveAllEmails(INITIAL_SAMPLE_EMAILS);
    await saveAllTasks(INITIAL_SAMPLE_TASKS);
    localStorage.setItem(DB_VERSION_KEY, 'true');
    return {
      emails: INITIAL_SAMPLE_EMAILS,
      tasks: INITIAL_SAMPLE_TASKS,
    };
  }

  const emails = await getAllEmails();
  const tasks = await getAllTasks();

  return {
    emails: emails.length > 0 ? emails : INITIAL_SAMPLE_EMAILS,
    tasks: tasks.length > 0 ? tasks : INITIAL_SAMPLE_TASKS,
  };
}

export async function getAllEmails(): Promise<Email[]> {
  try {
    const db = await getIDB();
    return new Promise((resolve) => {
      const tx = db.transaction('emails', 'readonly');
      const store = tx.objectStore('emails');
      const req = store.getAll();
      req.onsuccess = () => {
        const results = req.result as Email[];
        if (results && results.length > 0) {
          resolve(results.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        } else {
          resolve(getFromLocalStorage<Email[]>(EMAILS_STORAGE_KEY, []));
        }
      };
      req.onerror = () => {
        resolve(getFromLocalStorage<Email[]>(EMAILS_STORAGE_KEY, []));
      };
    });
  } catch {
    return getFromLocalStorage<Email[]>(EMAILS_STORAGE_KEY, []);
  }
}

export async function saveEmail(email: Email): Promise<void> {
  // Sync to IndexedDB
  try {
    const db = await getIDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('emails', 'readwrite');
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.objectStore('emails').put(email);
    });
  } catch (e) {
    console.warn('IndexedDB saveEmail failed, using localStorage fallback', e);
  }

  // Sync to LocalStorage
  const current = getFromLocalStorage<Email[]>(EMAILS_STORAGE_KEY, []);
  const index = current.findIndex((e) => e.id === email.id);
  if (index >= 0) {
    current[index] = email;
  } else {
    current.unshift(email);
  }
  saveToLocalStorage(EMAILS_STORAGE_KEY, current);
}

export async function addSentReplyToEmail(
  emailId: string,
  reply: import('../types').SentReply
): Promise<Email | null> {
  const emails = await getAllEmails();
  const email = emails.find((e) => e.id === emailId);
  if (!email) return null;

  const updatedReplies = [...(email.sentReplies || []), reply];
  const updatedEmail: Email = {
    ...email,
    replyStatus: 'Sent (Demo)',
    sentReplies: updatedReplies,
  };

  await saveEmail(updatedEmail);
  return updatedEmail;
}

export async function saveAllEmails(emails: Email[]): Promise<void> {
  try {
    const db = await getIDB();
    const tx = db.transaction('emails', 'readwrite');
    const store = tx.objectStore('emails');
    store.clear();
    emails.forEach((email) => store.put(email));
  } catch (e) {
    // fallback
  }
  saveToLocalStorage(EMAILS_STORAGE_KEY, emails);
}

export async function deleteEmail(id: string): Promise<void> {
  try {
    const db = await getIDB();
    const tx = db.transaction('emails', 'readwrite');
    tx.objectStore('emails').delete(id);
  } catch (e) {
    // fallback
  }

  const current = getFromLocalStorage<Email[]>(EMAILS_STORAGE_KEY, []);
  saveToLocalStorage(
    EMAILS_STORAGE_KEY,
    current.filter((e) => e.id !== id)
  );
}

// Tasks Database Operations
export async function getAllTasks(): Promise<Task[]> {
  try {
    const db = await getIDB();
    return new Promise((resolve) => {
      const tx = db.transaction('tasks', 'readonly');
      const store = tx.objectStore('tasks');
      const req = store.getAll();
      req.onsuccess = () => {
        const results = req.result as Task[];
        if (results && results.length > 0) {
          resolve(results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
        } else {
          resolve(getFromLocalStorage<Task[]>(TASKS_STORAGE_KEY, []));
        }
      };
      req.onerror = () => {
        resolve(getFromLocalStorage<Task[]>(TASKS_STORAGE_KEY, []));
      };
    });
  } catch {
    return getFromLocalStorage<Task[]>(TASKS_STORAGE_KEY, []);
  }
}

export async function saveTask(task: Task): Promise<void> {
  try {
    const db = await getIDB();
    const tx = db.transaction('tasks', 'readwrite');
    tx.objectStore('tasks').put(task);
  } catch (e) {
    // fallback
  }

  const current = getFromLocalStorage<Task[]>(TASKS_STORAGE_KEY, []);
  const index = current.findIndex((t) => t.id === task.id);
  if (index >= 0) {
    current[index] = task;
  } else {
    current.unshift(task);
  }
  saveToLocalStorage(TASKS_STORAGE_KEY, current);
}

export async function saveAllTasks(tasks: Task[]): Promise<void> {
  try {
    const db = await getIDB();
    const tx = db.transaction('tasks', 'readwrite');
    const store = tx.objectStore('tasks');
    store.clear();
    tasks.forEach((task) => store.put(task));
  } catch (e) {
    // fallback
  }
  saveToLocalStorage(TASKS_STORAGE_KEY, tasks);
}

export async function deleteTask(id: string): Promise<void> {
  try {
    const db = await getIDB();
    const tx = db.transaction('tasks', 'readwrite');
    tx.objectStore('tasks').delete(id);
  } catch (e) {
    // fallback
  }

  const current = getFromLocalStorage<Task[]>(TASKS_STORAGE_KEY, []);
  saveToLocalStorage(
    TASKS_STORAGE_KEY,
    current.filter((t) => t.id !== id)
  );
}

export async function resetDatabaseToDefault(): Promise<{ emails: Email[]; tasks: Task[] }> {
  await saveAllEmails(INITIAL_SAMPLE_EMAILS);
  await saveAllTasks(INITIAL_SAMPLE_TASKS);
  localStorage.setItem(DB_VERSION_KEY, 'true');
  return {
    emails: INITIAL_SAMPLE_EMAILS,
    tasks: INITIAL_SAMPLE_TASKS,
  };
}

export async function exportDatabaseBackup(): Promise<string> {
  const emails = await getAllEmails();
  const tasks = await getAllTasks();
  return JSON.stringify({
    exportedAt: new Date().toISOString(),
    emails,
    tasks,
  }, null, 2);
}
