import { Category, Priority, AISummary, ReplyDraft } from '../types';

export interface AnalysisResponse {
  success: boolean;
  isDemoFallback: boolean;
  category: Category;
  priority: Priority;
  confidence: number;
  summary: string;
  keyPoints: string[];
  sentiment: 'Neutral' | 'Action-Required' | 'Informational' | 'Appreciative';
  tasks: Array<{
    title: string;
    deadline: string;
    priority: Priority;
    description?: string;
  }>;
  suggestedReplies: ReplyDraft[];
  modelUsed: string;
  error?: string;
}

export async function checkServerGeminiStatus(): Promise<{
  available: boolean;
  model: string;
  reason?: string;
}> {
  try {
    const res = await fetch('/api/gemini/status');
    if (!res.ok) {
      return { available: false, model: 'gemini-3.8-flash', reason: `Server returned ${res.status}` };
    }
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { available: false, model: 'gemini-3.8-flash', reason: err.message || 'Network error' };
  }
}

export async function requestEmailAnalysis(email: {
  sender: string;
  subject: string;
  body: string;
  receivedAt?: string;
}): Promise<AnalysisResponse> {
  try {
    const res = await fetch('/api/gemini/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(email),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        return {
          success: true,
          isDemoFallback: false,
          category: data.category,
          priority: data.priority,
          confidence: data.confidence,
          summary: data.summary,
          keyPoints: data.keyPoints || [],
          sentiment: data.sentiment || 'Informational',
          tasks: data.tasks || [],
          suggestedReplies: data.suggestedReplies || [],
          modelUsed: data.modelUsed || 'gemini-3.8-flash',
        };
      }
    }
  } catch (err) {
    console.warn('Gemini API call failed, falling back to intelligent demo mode parser', err);
  }

  // Graceful local heuristic fallback when API key is not present or offline
  return generateDemoHeuristicAnalysis(email);
}

export async function requestSmartReply(params: {
  email: { sender: string; subject: string; body: string };
  tone: 'professional' | 'friendly' | 'formal-academic' | 'polite-decline' | 'short-acknowledgement';
  userNotes?: string;
}): Promise<{ replyBody: string; subject: string; modelUsed: string; isDemoFallback: boolean }> {
  try {
    const res = await fetch('/api/gemini/smart-reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        return {
          replyBody: data.replyBody,
          subject: data.subject,
          modelUsed: data.modelUsed || 'gemini-3.8-flash',
          isDemoFallback: false,
        };
      }
    }
  } catch (err) {
    console.warn('Smart Reply API call failed, falling back to heuristic template', err);
  }

  return generateDemoHeuristicReply(params);
}

// Local intelligent heuristic engine for demo mode without API credentials
function generateDemoHeuristicAnalysis(email: {
  sender: string;
  subject: string;
  body: string;
}): AnalysisResponse {
  const text = `${email.sender} ${email.subject} ${email.body}`.toLowerCase();

  // 1. Classification
  let category: Category = 'Work';
  if (
    text.includes('prof') ||
    text.includes('exam') ||
    text.includes('assignment') ||
    text.includes('course') ||
    text.includes('syllabus') ||
    text.includes('lab') ||
    text.includes('university') ||
    text.includes('.edu')
  ) {
    category = 'Academic';
  } else if (
    text.includes('urgent') ||
    text.includes('critical') ||
    text.includes('security alert') ||
    text.includes('exposed secret') ||
    text.includes('immediately') ||
    text.includes('compromised')
  ) {
    category = 'Urgent';
  } else if (
    text.includes('discount') ||
    text.includes('coupon') ||
    text.includes('deal') ||
    text.includes('sale') ||
    text.includes('unsubscribe') ||
    text.includes('newsletter')
  ) {
    category = 'Promotional';
  } else if (
    text.includes('dinner') ||
    text.includes('roommate') ||
    text.includes('hackathon') ||
    text.includes('weekend') ||
    text.includes('party') ||
    text.includes('movie') ||
    text.includes('bill')
  ) {
    category = 'Personal';
  }

  // 2. Priority
  let priority: Priority = 'Medium';
  if (category === 'Urgent' || text.includes('asap') || text.includes('within 24 hours') || text.includes('deadline')) {
    priority = 'Urgent';
  } else if (text.includes('interview') || text.includes('tomorrow') || text.includes('due this week')) {
    priority = 'High';
  } else if (category === 'Promotional') {
    priority = 'Low';
  }

  // 3. Extract Deadlines & Tasks
  const tasks: AnalysisResponse['tasks'] = [];
  const lines = email.body.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (
      trimmed.match(/(due|submit|schedule|reply|pay|review|complete|book|confirm|send)/i) &&
      trimmed.length > 10 &&
      trimmed.length < 160
    ) {
      let deadline = 'Upcoming';
      if (trimmed.match(/today/i)) deadline = 'Today';
      else if (trimmed.match(/tomorrow/i)) deadline = 'Tomorrow';
      else if (trimmed.match(/friday/i)) deadline = 'This Friday';
      else if (trimmed.match(/thursday/i)) deadline = 'This Thursday';
      else if (trimmed.match(/sunday/i)) deadline = 'This Sunday';
      else if (trimmed.match(/hour/i)) deadline = 'Within 2 hours';

      tasks.push({
        title: trimmed.replace(/^[0-9.-]\s*/, ''),
        deadline,
        priority: priority === 'Urgent' ? 'Urgent' : 'High',
        description: `Action item from email: ${email.subject}`,
      });
      if (tasks.length >= 3) break;
    }
  }

  if (tasks.length === 0) {
    tasks.push({
      title: `Follow up regarding: ${email.subject.slice(0, 50)}`,
      deadline: 'Within 3 business days',
      priority: priority,
      description: 'Review sender instructions and reply if necessary.',
    });
  }

  // 4. Summary & Key Points
  const firstSentences = email.body
    .replace(/\n+/g, ' ')
    .split(/[.?!]/)
    .filter((s) => s.trim().length > 15)
    .slice(0, 2)
    .join('. ');

  const summary = firstSentences ? `${firstSentences.trim()}.` : `Communication from ${email.sender} regarding ${email.subject}.`;

  const keyPoints = [
    `Sender: ${email.sender}`,
    category === 'Urgent' ? 'Requires rapid attention or action' : `Categorized under ${category} workflow`,
    tasks.length > 0 ? `Detected ${tasks.length} actionable item(s)` : 'For informational reference',
  ];

  // 5. Suggested Replies
  const suggestedReplies: ReplyDraft[] = [
    {
      tone: 'professional',
      label: 'Professional Acknowledgment',
      subject: `Re: ${email.subject}`,
      body: `Hi ${email.sender.split(' ')[0] || 'there'},\n\nThank you for reaching out regarding "${email.subject}". I have received your message and will review the details right away.\n\nBest regards,\n[Your Name]`,
    },
    {
      tone: 'formal-academic',
      label: 'Formal Student Response',
      subject: `Re: ${email.subject}`,
      body: `Dear ${email.sender},\n\nThank you for the update. I have reviewed the instructions and will make sure all requirements are fulfilled accordingly.\n\nSincerely,\n[Your Name]\nComputer Science Student`,
    },
    {
      tone: 'short-acknowledgement',
      label: 'Quick Confirmation',
      subject: `Re: ${email.subject}`,
      body: `Received with thanks! I'm on it and will follow up shortly.\n\nBest,\n[Your Name]`,
    },
  ];

  return {
    success: true,
    isDemoFallback: true,
    category,
    priority,
    confidence: 0.88,
    summary,
    keyPoints,
    sentiment: category === 'Urgent' ? 'Action-Required' : 'Informational',
    tasks,
    suggestedReplies,
    modelUsed: 'Demo Heuristics Engine (Offline/Sample Mode)',
  };
}

function generateDemoHeuristicReply(params: {
  email: { sender: string; subject: string; body: string };
  tone: 'professional' | 'friendly' | 'formal-academic' | 'polite-decline' | 'short-acknowledgement';
  userNotes?: string;
}): { replyBody: string; subject: string; modelUsed: string; isDemoFallback: boolean } {
  const senderName = params.email.sender.split(' ')[0] || 'there';
  const subject = params.email.subject.startsWith('Re:') ? params.email.subject : `Re: ${params.email.subject}`;

  let body = '';
  switch (params.tone) {
    case 'friendly':
      body = `Hi ${senderName}!\n\nThanks for reaching out! Great to hear from you. I went through your message about "${params.email.subject}" and sounds great.\n\n${params.userNotes ? `${params.userNotes}\n\n` : ''}Talk soon!\n\nCheers,\n[Your Name]`;
      break;
    case 'formal-academic':
      body = `Dear ${params.email.sender},\n\nThank you for contacting me regarding "${params.email.subject}". I have noted the deliverables and deadlines described.\n\n${params.userNotes ? `${params.userNotes}\n\n` : ''}Please let me know if you require any additional materials.\n\nRespectfully,\n[Your Name]`;
      break;
    case 'polite-decline':
      body = `Hi ${senderName},\n\nThank you for thinking of me and sharing the details regarding "${params.email.subject}". Unfortunately, due to prior academic and project commitments at this time, I won't be able to take this on.\n\nI really appreciate your consideration and hope we can collaborate in the future.\n\nBest regards,\n[Your Name]`;
      break;
    case 'short-acknowledgement':
      body = `Hi ${senderName},\n\nGot it, thank you for confirming! I'll proceed accordingly.\n\nBest,\n[Your Name]`;
      break;
    case 'professional':
    default:
      body = `Dear ${params.email.sender},\n\nThank you for your message regarding "${params.email.subject}".\n\nI have carefully reviewed your notes and will take care of the next steps.\n\n${params.userNotes ? `Additional notes: ${params.userNotes}\n\n` : ''}Please let me know if you need any clarification in the interim.\n\nBest regards,\n[Your Name]`;
      break;
  }

  return {
    replyBody: body,
    subject,
    modelUsed: 'Demo Heuristics Engine',
    isDemoFallback: true,
  };
}
