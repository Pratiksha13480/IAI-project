import React, { useState, useEffect } from 'react';
import {
  initializeDatabase,
  saveEmail,
  deleteEmail as dbDeleteEmail,
  saveTask,
  deleteTask as dbDeleteTask,
  resetDatabaseToDefault,
} from './services/storage';
import { checkServerGeminiStatus } from './services/geminiClient';
import { Email, Task, Category } from './types';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { EmailListView } from './components/EmailListView';
import { TasksView } from './components/TasksView';
import { EmailDetailModal } from './components/EmailDetailModal';
import { NewEmailModal } from './components/NewEmailModal';
import { VSCodeGuideModal } from './components/VSCodeGuideModal';
import { Menu, Sparkles, Loader2 } from 'lucide-react';

export default function App() {
  const [emails, setEmails] = useState<Email[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [isNewEmailModalOpen, setIsNewEmailModalOpen] = useState<boolean>(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState<boolean>(false);
  const [isOpenMobileSidebar, setIsOpenMobileSidebar] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const [aiStatus, setAiStatus] = useState<{
    available: boolean;
    model: string;
    reason?: string;
  }>({
    available: false,
    model: 'gemini-3.8-flash',
  });

  // Load database and check Gemini API availability
  useEffect(() => {
    async function loadInitialData() {
      try {
        const { emails: loadedEmails, tasks: loadedTasks } = await initializeDatabase();
        setEmails(loadedEmails);
        setTasks(loadedTasks);

        const status = await checkServerGeminiStatus();
        setAiStatus(status);
      } catch (err) {
        console.error('Initialization error', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadInitialData();
  }, []);

  // Handlers for Emails
  const handleSelectEmail = (email: Email) => {
    // Mark as read if not already read
    if (!email.read) {
      const updated = { ...email, read: true };
      setEmails((prev) => prev.map((e) => (e.id === email.id ? updated : e)));
      saveEmail(updated);
      setSelectedEmail(updated);
    } else {
      setSelectedEmail(email);
    }
  };

  const handleUpdateEmail = (updatedEmail: Email) => {
    setEmails((prev) => prev.map((e) => (e.id === updatedEmail.id ? updatedEmail : e)));
    saveEmail(updatedEmail);
    setSelectedEmail(updatedEmail);
  };

  const handleToggleStar = (emailId: string) => {
    setEmails((prev) =>
      prev.map((e) => {
        if (e.id === emailId) {
          const updated = { ...e, starred: !e.starred };
          saveEmail(updated);
          return updated;
        }
        return e;
      })
    );
  };

  const handleToggleRead = (emailId: string) => {
    setEmails((prev) =>
      prev.map((e) => {
        if (e.id === emailId) {
          const updated = { ...e, read: !e.read };
          saveEmail(updated);
          return updated;
        }
        return e;
      })
    );
  };

  const handleDeleteEmail = (emailId: string) => {
    setEmails((prev) => prev.filter((e) => e.id !== emailId));
    dbDeleteEmail(emailId);
    if (selectedEmail?.id === emailId) {
      setSelectedEmail(null);
    }
  };

  // Handlers for Tasks
  const handleToggleTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const completed = !t.completed;
          const updated: Task = {
            ...t,
            completed,
            completedAt: completed ? new Date().toISOString() : undefined,
          };
          saveTask(updated);
          return updated;
        }
        return t;
      })
    );
  };

  const handleAddTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
    saveTask(newTask);
  };

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updatedTask.id ? updatedTask : t)));
    saveTask(updatedTask);
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    dbDeleteTask(taskId);
  };

  // Handler for New Simulated Email
  const handleEmailCreated = (newEmail: Email, newTasks: Task[]) => {
    setEmails((prev) => [newEmail, ...prev]);
    saveEmail(newEmail);

    if (newTasks.length > 0) {
      setTasks((prev) => [...newTasks, ...prev]);
      newTasks.forEach((t) => saveTask(t));
    }

    // Auto open newly created email so user sees AI magic
    setSelectedEmail(newEmail);
  };

  // Handler to Reset Database to Defaults
  const handleResetData = async () => {
    const res = await resetDatabaseToDefault();
    setEmails(res.emails);
    setTasks(res.tasks);
    setSelectedEmail(null);
  };

  // Metrics calculations for sidebar badges
  const unreadCount = emails.filter((e) => !e.read).length;
  const urgentCount = emails.filter((e) => e.priority === 'Urgent' || e.category === 'Urgent').length;
  const pendingTasksCount = tasks.filter((t) => !t.completed).length;

  const categoryCounts: Record<Category, number> = {
    Academic: emails.filter((e) => e.category === 'Academic').length,
    Work: emails.filter((e) => e.category === 'Work').length,
    Urgent: emails.filter((e) => e.category === 'Urgent').length,
    Personal: emails.filter((e) => e.category === 'Personal').length,
    Promotional: emails.filter((e) => e.category === 'Promotional').length,
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 mb-4 animate-bounce">
          <Sparkles className="w-6 h-6" />
        </div>
        <h2 className="text-base font-bold text-slate-800">Initializing SmartMail AI...</h2>
        <p className="text-xs text-slate-500 mt-1">Connecting to database and verifying AI agents</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        unreadCount={unreadCount}
        urgentCount={urgentCount}
        pendingTasksCount={pendingTasksCount}
        categoryCounts={categoryCounts}
        onOpenGuideModal={() => setIsGuideModalOpen(true)}
        isOpenMobile={isOpenMobileSidebar}
        onCloseMobile={() => setIsOpenMobileSidebar(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header Bar */}
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => setIsOpenMobileSidebar(true)}
            className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-1.5 font-bold text-slate-900 text-sm">
            <span>SmartMail</span>
            <span className="px-1.5 py-0.5 text-[10px] bg-blue-100 text-blue-700 rounded font-black">AI</span>
          </div>
          <button
            onClick={() => setIsNewEmailModalOpen(true)}
            className="p-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold"
          >
            + Mail
          </button>
        </div>

        {/* Global Navbar */}
        <Navbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          aiStatus={aiStatus}
          onOpenNewEmailModal={() => setIsNewEmailModalOpen(true)}
          onOpenGuideModal={() => setIsGuideModalOpen(true)}
          onResetData={handleResetData}
          activeTab={activeTab}
        />

        {/* Main View Router */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              emails={emails}
              tasks={tasks}
              onSelectEmail={handleSelectEmail}
              onToggleTask={handleToggleTask}
              onNavigateToTab={(tab, cat) => {
                setActiveTab(tab);
                if (cat) setSelectedCategory(cat);
              }}
              onOpenNewEmailModal={() => setIsNewEmailModalOpen(true)}
            />
          )}

          {activeTab === 'emails' && (
            <EmailListView
              emails={emails}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onSelectEmail={handleSelectEmail}
              onToggleStar={handleToggleStar}
              onToggleRead={handleToggleRead}
              onDeleteEmail={handleDeleteEmail}
              onOpenNewEmailModal={() => setIsNewEmailModalOpen(true)}
            />
          )}

          {activeTab === 'tasks' && (
            <TasksView
              tasks={tasks}
              onToggleTask={handleToggleTask}
              onAddTask={handleAddTask}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
            />
          )}
        </main>
      </div>

      {/* Email Detail & AI Intelligence Modal */}
      <EmailDetailModal
        email={selectedEmail}
        onClose={() => setSelectedEmail(null)}
        onUpdateEmail={handleUpdateEmail}
        onAddTask={handleAddTask}
        existingTasks={tasks}
      />

      {/* New Simulated Email & Real-time AI Analysis Modal */}
      <NewEmailModal
        isOpen={isNewEmailModalOpen}
        onClose={() => setIsNewEmailModalOpen(false)}
        onEmailCreated={handleEmailCreated}
      />

      {/* VS Code Setup & Download Guide for Student Developers */}
      <VSCodeGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
      />
    </div>
  );
}
