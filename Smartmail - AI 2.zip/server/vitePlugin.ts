import type { Plugin } from 'vite';
import {
  checkGeminiStatus,
  analyzeEmailWithGemini,
  generateSmartReplyWithGemini,
} from './geminiService';

export function geminiApiPlugin(): Plugin {
  return {
    name: 'gemini-api-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/gemini')) {
          return next();
        }

        // Helper to send JSON response
        const sendJson = (statusCode: number, data: any) => {
          res.statusCode = statusCode;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(data));
        };

        // Helper to parse JSON body
        const parseBody = (): Promise<any> => {
          if ((req as any).body) {
            return Promise.resolve((req as any).body);
          }
          return new Promise((resolve, reject) => {
            let body = '';
            req.on('data', (chunk) => {
              body += chunk;
            });
            req.on('end', () => {
              try {
                resolve(body ? JSON.parse(body) : {});
              } catch (e) {
                reject(e);
              }
            });
            req.on('error', (err) => reject(err));
          });
        };

        try {
          // Status endpoint
          if (req.url === '/api/gemini/status' && req.method === 'GET') {
            const status = await checkGeminiStatus();
            return sendJson(200, status);
          }

          // Email analyze endpoint
          if (req.url === '/api/gemini/analyze' && req.method === 'POST') {
            const body = await parseBody();
            if (!body.subject && !body.body) {
              return sendJson(400, { error: 'Subject or body is required' });
            }
            const analysis = await analyzeEmailWithGemini({
              sender: body.sender || 'Unknown',
              subject: body.subject || '',
              body: body.body || '',
              receivedAt: body.receivedAt,
            });
            return sendJson(200, { success: true, ...analysis });
          }

          // Smart Reply endpoint
          if (req.url === '/api/gemini/smart-reply' && req.method === 'POST') {
            const body = await parseBody();
            if (!body.email) {
              return sendJson(400, { error: 'Email object is required' });
            }
            const reply = await generateSmartReplyWithGemini({
              email: body.email,
              tone: body.tone || 'professional',
              userNotes: body.userNotes,
            });
            return sendJson(200, { success: true, ...reply });
          }

          return next();
        } catch (error: any) {
          console.error('[Gemini API Server Error]:', error);
          return sendJson(500, {
            success: false,
            error: error?.message || 'Internal Server Error while communicating with Gemini API',
          });
        }
      });
    },
  };
}
