import { GoogleGenAI, Type } from '@google/genai';

// Initialize Gemini client with proper telemetry header
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

export interface EmailAnalysisResult {
  category: 'Academic' | 'Work' | 'Personal' | 'Promotional' | 'Urgent';
  priority: 'Urgent' | 'High' | 'Medium' | 'Low';
  confidence: number;
  summary: string;
  keyPoints: string[];
  sentiment: 'Neutral' | 'Action-Required' | 'Informational' | 'Appreciative';
  tasks: Array<{
    title: string;
    deadline: string;
    priority: 'Urgent' | 'High' | 'Medium' | 'Low';
    description?: string;
  }>;
  suggestedReplies: Array<{
    tone: string;
    label: string;
    body: string;
  }>;
  modelUsed: string;
}

export async function checkGeminiStatus(): Promise<{
  available: boolean;
  model: string;
  reason?: string;
}> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      available: false,
      model: 'gemini-3.8-flash',
      reason: 'Demo Mode (Local Intelligent Heuristics)',
    };
  }
  return { available: true, model: 'gemini-3.8-flash' };
}

export async function analyzeEmailWithGemini(email: {
  sender: string;
  subject: string;
  body: string;
  receivedAt?: string;
}): Promise<EmailAnalysisResult> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server');
  }

  const prompt = `You are SmartMail AI, an intelligent email management and task automation agent.
Analyze the following email comprehensively for a student/professional.

Email Details:
From: ${email.sender}
Subject: ${email.subject}
Date: ${email.receivedAt || new Date().toISOString()}
Content:
"""
${email.body}
"""

Classification Rules:
- Category MUST be exactly one of: Academic, Work, Personal, Promotional, Urgent.
  * Academic: University coursework, professors, exams, research labs, study groups, campus alerts.
  * Work: Job offers, internships, clients, project deadlines, team PR reviews, corporate.
  * Personal: Friends, family, social events, private hobbies.
  * Promotional: Marketing, newsletters, discounts, automated service ads.
  * Urgent: Anything requiring immediate response within 24-48 hours, security alerts, crucial deadlines.
- Priority: Urgent, High, Medium, Low.
- Summary: 2 concise, executive-level sentences explaining the core request or message.
- Key Points: 2-3 bullet items.
- Tasks: Extract ANY action items, submissions, meetings, or requests. Provide clear, actionable titles and specific deadlines (format as 'YYYY-MM-DD' or relative like 'Tomorrow by 5 PM' or 'This Friday').
- Suggested Replies: Provide 3 distinct ready-to-edit reply drafts (e.g., Professional/Confirming, Polite Decline/Delay, Request Clarification).`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: {
            type: Type.STRING,
            description: 'One of: Academic, Work, Personal, Promotional, Urgent',
          },
          priority: {
            type: Type.STRING,
            description: 'One of: Urgent, High, Medium, Low',
          },
          confidence: {
            type: Type.NUMBER,
            description: 'Confidence score from 0.0 to 1.0',
          },
          summary: {
            type: Type.STRING,
            description: 'Concise 2-sentence summary of the email',
          },
          keyPoints: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2 to 3 main points',
          },
          sentiment: {
            type: Type.STRING,
            description: 'One of: Neutral, Action-Required, Informational, Appreciative',
          },
          tasks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING, description: 'Action item title' },
                deadline: { type: Type.STRING, description: 'Due date or deadline' },
                priority: {
                  type: Type.STRING,
                  description: 'Urgent, High, Medium, or Low',
                },
                description: { type: Type.STRING, description: 'Short context' },
              },
              required: ['title', 'deadline', 'priority'],
            },
          },
          suggestedReplies: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tone: { type: Type.STRING, description: 'Tone identifier (e.g. professional, polite-decline, student-formal)' },
                label: { type: Type.STRING, description: 'User-friendly label (e.g. Confirm & Accept, Inquire for Details)' },
                body: { type: Type.STRING, description: 'Full editable draft email body text' },
              },
              required: ['tone', 'label', 'body'],
            },
          },
        },
        required: ['category', 'priority', 'summary', 'keyPoints', 'tasks', 'suggestedReplies'],
      },
    },
  });

  const parsed = JSON.parse(response.text || '{}');
  
  // Validate category fallback
  const validCategories = ['Academic', 'Work', 'Personal', 'Promotional', 'Urgent'];
  const category = validCategories.includes(parsed.category) ? parsed.category : 'Work';

  const validPriorities = ['Urgent', 'High', 'Medium', 'Low'];
  const priority = validPriorities.includes(parsed.priority) ? parsed.priority : 'Medium';

  return {
    category,
    priority,
    confidence: parsed.confidence || 0.95,
    summary: parsed.summary || 'Summary unavailable.',
    keyPoints: parsed.keyPoints || [],
    sentiment: parsed.sentiment || 'Informational',
    tasks: (parsed.tasks || []).map((t: any) => ({
      title: t.title || 'Follow up on email',
      deadline: t.deadline || 'Upcoming',
      priority: validPriorities.includes(t.priority) ? t.priority : 'Medium',
      description: t.description || '',
    })),
    suggestedReplies: parsed.suggestedReplies || [],
    modelUsed: 'gemini-3.8-flash',
  };
}

export async function generateSmartReplyWithGemini(params: {
  email: { sender: string; subject: string; body: string };
  tone: 'professional' | 'friendly' | 'formal-academic' | 'polite-decline' | 'short-acknowledgement';
  userNotes?: string;
}): Promise<{ replyBody: string; subject: string; modelUsed: string }> {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server');
  }

  const prompt = `You are SmartMail AI's Smart Reply agent.
Generate an editable, professional email reply draft for the user.
Note: The user will review and edit this draft before sending. Never auto-send.

Incoming Email:
From: ${params.email.sender}
Subject: ${params.email.subject}
Body:
"""
${params.email.body}
"""

Desired Tone: ${params.tone}
${params.userNotes ? `Additional User Instructions / Key points to include: ${params.userNotes}` : ''}

Draft a clear, polite, and well-structured response appropriate for the relationship and tone requested. Include polite greeting, body paragraphs, and professional sign-off with placeholder [Your Name].`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: prompt,
  });

  const replyBody = response.text || 'Thank you for your email. I will review this and get back to you shortly.\n\nBest regards,\n[Your Name]';
  const subject = params.email.subject.startsWith('Re:') ? params.email.subject : `Re: ${params.email.subject}`;

  return {
    replyBody,
    subject,
    modelUsed: 'gemini-3.8-flash',
  };
}
